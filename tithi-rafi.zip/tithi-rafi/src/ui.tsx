import React, {createContext, useContext, useEffect, useState} from 'react';
import {useCurrentFrame, useVideoConfig, spring, interpolate, staticFile, delayRender, continueRender} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';
import {FPS, DIALOGUES} from './timing';

const {fontFamily} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});
export const FONT = fontFamily;

export const usePop = (start = 0) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - start, fps, config: {damping: 12}});
};

// ---------- SRT cues ----------
type Cue = {s: number; e: number; t: string};
const toSec = (h: string) => {
  const m = h.match(/(\d+):(\d+):(\d+),(\d+)/)!;
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

const parseSrt = (txt: string): Cue[] => {
  const raw: Cue[] = [];
  for (const block of txt.replace(/\r/g, '').split(/\n\s*\n/)) {
    const lines = block.trim().split('\n');
    if (lines.length < 3) continue;
    const [a, b] = lines[1].split('-->');
    const t = lines.slice(2).join(' ').trim();
    if (t.includes('[')) continue;
    raw.push({s: toSec(a), e: toSec(b), t});
  }
  const out: Cue[] = [];
  let cur: Cue | null = null;
  for (const c of raw) {
    if (cur && c.s - cur.e > 0.6) {
      out.push(cur);
      cur = null;
    }
    cur = cur ? {s: cur.s, e: c.e, t: cur.t + ' ' + c.t} : {...c};
    const words = cur.t.split(' ').length;
    if (words >= 4 || /[।?!]$/.test(cur.t)) {
      out.push(cur);
      cur = null;
    }
  }
  if (cur) out.push(cur);
  return out;
};

const CueCtx = createContext<Cue[]>([]);

export const CueProvider: React.FC<{children: React.ReactNode}> = ({children}) => {
  const [cues, setCues] = useState<Cue[]>([]);
  const [handle] = useState(() => delayRender('srt'));
  useEffect(() => {
    fetch(staticFile('subs.srt'))
      .then((r) => r.text())
      .then((txt) => setCues(parseSrt(txt)))
      .finally(() => continueRender(handle));
  }, [handle]);
  return <CueCtx.Provider value={cues}>{children}</CueCtx.Provider>;
};

// ---------- ক্যাপশন (ভাসমান ওভারলে) ----------
export const Caption: React.FC<{g: number; hidden?: boolean}> = ({g, hidden}) => {
  const cues = useContext(CueCtx);
  const t = g / FPS;
  const cue = cues.find((c) => t >= c.s && t <= c.e + 0.15);
  if (!cue || hidden) return null;
  const p = interpolate(g, [cue.s * FPS, cue.s * FPS + 6], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const words = cue.t.split(' ');
  const key = words.reduce((a, b) => (b.length > a.length ? b : a), '');
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 70, display: 'flex', justifyContent: 'center', opacity: p, transform: `translateY(${(1 - p) * 24}px)`}}>
      <div style={{fontFamily: FONT, fontSize: 56, fontWeight: 600, color: '#fff', background: 'rgba(20,20,25,0.62)', padding: '12px 36px', borderRadius: 28, whiteSpace: 'nowrap'}}>
        {words.map((w, i) => (
          <span key={i} style={w === key ? {color: '#FFD166', fontWeight: 700} : undefined}>{w}{' '}</span>
        ))}
      </div>
    </div>
  );
};

// ---------- সংলাপ বাবল ----------
type Side = 'left' | 'right';
export const Bubble: React.FC<{text: string; x: number; y: number; side?: Side; w?: number; start?: number}> = ({text, x, y, side = 'left', w = 640, start = 0}) => {
  const p = usePop(start);
  const tail = side === 'left' ? {left: 60} : {right: 60};
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, transform: `translate(${side === 'left' ? '-60px' : `calc(-100% + 60px)`}, -100%) scale(${p})`, transformOrigin: side === 'left' ? '60px 100%' : 'calc(100% - 60px) 100%'}}>
      <div style={{fontFamily: FONT, background: '#fff', border: '4px solid #222', borderRadius: 36, padding: '22px 30px', fontSize: 44, fontWeight: 600, lineHeight: 1.35, color: '#222', boxShadow: '0 8px 0 rgba(0,0,0,0.15)'}}>{text}</div>
      <div style={{position: 'absolute', bottom: -30, ...tail, width: 0, height: 0, borderLeft: '22px solid transparent', borderRight: '22px solid transparent', borderTop: '32px solid #222'}} />
    </div>
  );
};

export type Who = 'tithi' | 'rafi';
export const speakerAt = (g: number): Who | null => {
  const t = g / FPS;
  const d = DIALOGUES.find(([s, e]) => t >= s && t <= e);
  return d ? d[2] : null;
};

// সিনের ভেতরে সক্রিয় সংলাপের বাবল দেখায়। from = সিনের শুরুর ফ্রেম।
export const DialogueLayer: React.FC<{from: number; pos: Record<Who, {x: number; y: number; side: Side}>}> = ({from, pos}) => {
  const g = useCurrentFrame() + from;
  const t = g / FPS;
  const d = DIALOGUES.find(([s, e]) => t >= s && t <= e);
  if (!d) return null;
  const p = pos[d[2]];
  return <Bubble key={d[0]} text={d[3]} x={p.x} y={p.y} side={p.side} start={Math.round(d[0] * FPS) - from} />;
};

// ---------- পিল-ব্যাজ, স্ট্যাম্প, নোট কার্ড, আইকন ----------
export const Pill: React.FC<{text: string; x?: number; y?: number; color?: string; start?: number}> = ({text, x = 60, y = 50, color = '#FFD166', start = 0}) => {
  const p = usePop(start);
  return (
    <div style={{position: 'absolute', left: x, top: y, fontFamily: FONT, fontSize: 38, fontWeight: 700, color: '#222', background: color, border: '3px solid #222', borderRadius: 999, padding: '8px 30px', transform: `scale(${p})`, transformOrigin: 'left center'}}>{text}</div>
  );
};

export const Stamp: React.FC<{text: string; x: number; y: number; start?: number; rot?: number; color?: string}> = ({text, x, y, start = 0, rot = -8, color = '#D62828'}) => {
  const p = usePop(start);
  const s = 1 + (1 - Math.min(p, 1)) * 2.2;
  return (
    <div style={{position: 'absolute', left: x, top: y, fontFamily: FONT, fontSize: 84, fontWeight: 700, color, border: `8px solid ${color}`, borderRadius: 18, padding: '4px 28px', opacity: Math.min(p, 1), transform: `rotate(${rot}deg) scale(${s})`, background: 'rgba(255,255,255,0.75)'}}>{text}</div>
  );
};

export const NoteCard: React.FC<{text: string; x: number; y: number; start?: number; w?: number}> = ({text, x, y, start = 0, w = 480}) => {
  const p = usePop(start);
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, fontFamily: FONT, fontSize: 42, fontWeight: 600, color: '#222', background: '#FFF3A8', border: '3px solid #222', borderRadius: 14, padding: '26px 28px', transform: `rotate(-3deg) scale(${p})`, boxShadow: '0 10px 0 rgba(0,0,0,0.15)'}}>
      <span style={{position: 'absolute', top: -26, left: w / 2 - 20, fontSize: 44}}>📌</span>
      {text}
    </div>
  );
};

export const IconPop: React.FC<{emoji: string; x: number; y: number; size?: number; start?: number}> = ({emoji, x, y, size = 120, start = 0}) => {
  const frame = useCurrentFrame();
  const p = usePop(start);
  return (
    <div style={{position: 'absolute', left: x, top: y + Math.sin(frame / 12) * 8, fontSize: size, transform: `scale(${p})`}}>{emoji}</div>
  );
};

// স্ক্রিন শেক র‍্যাপার
export const Shake: React.FC<{on: boolean; children: React.ReactNode}> = ({on, children}) => {
  const frame = useCurrentFrame();
  const dx = on ? Math.sin(frame * 3.1) * 7 : 0;
  const dy = on ? Math.cos(frame * 2.7) * 6 : 0;
  return <div style={{position: 'absolute', inset: 0, transform: `translate(${dx}px, ${dy}px)`}}>{children}</div>;
};
