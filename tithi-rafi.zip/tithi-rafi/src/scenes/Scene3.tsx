import React from 'react';
import {useCurrentFrame, interpolate} from 'remotion';
import {Person} from '../characters';
import {RestaurantBG, TableFront, Stage} from './common';
import {IconPop, NoteCard, Caption, DialogueLayer, speakerAt} from '../ui';
import {SCENES, FPS} from '../timing';

const F = SCENES.s3.from;
const L = (s: number) => Math.round(s * FPS) - F;

export const Scene3: React.FC = () => {
  const frame = useCurrentFrame();
  const g = frame + F;
  const t = g / FPS;
  const talk = speakerAt(g);
  const tMood = t < 56.9 ? 'sad' : t < 63.8 ? 'hurt' : t < 65.3 ? 'angry' : 'hurt';
  const glassRot = frame > L(66) && frame < L(71) ? Math.sin((frame - L(66)) / 5) * 16 : 0;
  const waiterX = interpolate(frame, [L(71), L(71) + 25], [2050, 1720], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const note = t >= 56.9 && t < 59.9;
  return (
    <>
      <RestaurantBG />
      <Stage>
        {t >= 71 && <Person kind='waiter' x={waiterX} y={400} scale={0.8} flip mood='neutral' />}
        <Person kind='tithi' x={620} y={360} scale={1.5} mood={tMood} talking={talk === 'tithi'} />
        <Person kind='rafi' x={1330} y={360} scale={1.5} flip mood='tired' talking={talk === 'rafi'} tremble={t >= 66 && t < 71} />
        <TableFront melt={0.9} glass glassRot={glassRot} />
      </Stage>

      {t >= 50.5 && t < 53.6 && <IconPop emoji='🗓️' x={1450} y={300} size={130} start={L(50.5)} />}
      {note && <NoteCard text='📅 প্রতিবারই “মিটিং”' x={700} y={110} start={L(56.9)} w={520} />}
      {t >= 66 && t < 71 && <IconPop emoji='💧' x={1230} y={470} size={90} start={L(66)} />}

      <DialogueLayer from={F} pos={{tithi: {x: 560, y: 250, side: 'left'}, rafi: {x: 1330, y: 250, side: 'right'}}} />
      <Caption g={g} hidden={!!talk || note} />
    </>
  );
};
