import React from 'react';
import {useCurrentFrame, interpolate} from 'remotion';
import {Person} from '../characters';
import {RestaurantBG, TableFront, Stage} from './common';
import {Pill, IconPop, Stamp, Caption, DialogueLayer, speakerAt} from '../ui';
import {SCENES} from '../timing';

const F = SCENES.s1.from;

export const Scene1: React.FC = () => {
  const frame = useCurrentFrame();
  const g = frame + F;
  const talk = speakerAt(g);
  const rafiX = interpolate(frame, [357, 390], [2150, 1330], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const tMood = frame < 125 ? 'angry' : frame < 580 ? 'neutral' : 'sad';
  const stamp = frame >= 674;
  return (
    <>
      <RestaurantBG />
      <Stage>
        <Person kind='tithi' x={620} y={360} scale={1.5} mood={tMood} talking={talk === 'tithi'} tremble={frame < 125} />
        {frame >= 357 && <Person kind='rafi' x={rafiX} y={360} scale={1.5} flip mood='tired' talking={talk === 'rafi'} />}
        <TableFront melt={interpolate(frame, [0, 700], [0.5, 0.9])} />
      </Stage>

      <Pill text='রেস্তোরাঁ • সন্ধ্যা' start={0} />
      {frame < 125 && <IconPop emoji='🕒' x={1500} y={200} size={150} start={10} />}
      {frame >= 150 && frame < 240 && <IconPop emoji='🕯️' x={880} y={380} size={130} start={150} />}
      {frame >= 270 && frame < 345 && <IconPop emoji='☕' x={650} y={450} size={120} start={270} />}
      {frame >= 405 && frame < 490 && <IconPop emoji='💦' x={1450} y={300} size={110} start={405} />}
      {frame >= 485 && frame < 550 && <IconPop emoji='👟' x={1500} y={520} size={110} start={485} />}
      {frame >= 580 && frame < 640 && <IconPop emoji='🎂' x={860} y={380} size={140} start={580} />}
      {stamp && <Stamp text='৩য় বার দেরি' x={1180} y={120} start={674} />}

      <DialogueLayer from={F} pos={{tithi: {x: 560, y: 250, side: 'left'}, rafi: {x: 1330, y: 250, side: 'right'}}} />
      <Caption g={g} hidden={!!talk || stamp} />
    </>
  );
};
