import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';
import {Person} from '../characters';
import {RestaurantBG, TableFront, Stage} from './common';
import {Jacket} from './props';
import {Pill, IconPop, NoteCard, Caption, DialogueLayer, speakerAt, usePop, Shake, FONT} from '../ui';
import {SCENES, FPS} from '../timing';

const F = SCENES.s4.from;
const L = (s: number) => Math.round(s * FPS) - F;
const C = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const DARK = 'radial-gradient(circle at 50% 40%, #2E3F6E, #151B33)';

const Node: React.FC<{x: number; icon: string; label: string; start: number}> = ({x, icon, label, start}) => {
  const p = usePop(start);
  return (
    <div style={{position: 'absolute', left: x, top: 360, width: 330, height: 360, background: '#FFFFFF', border: '5px solid #222', borderRadius: 36, textAlign: 'center', fontFamily: FONT, transform: `scale(${p})`, boxShadow: '0 12px 0 rgba(0,0,0,0.3)'}}>
      <div style={{fontSize: 150, marginTop: 30}}>{icon}</div>
      <div style={{fontSize: 44, fontWeight: 700, color: '#222', padding: '0 16px'}}>{label}</div>
    </div>
  );
};

const Arrow: React.FC<{x: number; start: number}> = ({x, start}) => {
  const p = usePop(start);
  return <div style={{position: 'absolute', left: x, top: 480, fontSize: 110, color: '#FFD166', fontFamily: FONT, transform: `scale(${p})`}}>➜</div>;
};

const Bag: React.FC<{rot: number}> = ({rot}) => (
  <g transform={`translate(1640 905) rotate(${rot})`}>
    <rect x={-55} y={-150} width={110} height={150} rx={22} fill='#2B2B2B' stroke='#222' strokeWidth={3} />
    <rect x={-40} y={-120} width={80} height={46} rx={10} fill='#3A3A3A' stroke='#222' strokeWidth={2.5} />
    <path d='M-30 -150 Q0 -190 30 -150' fill='none' stroke='#222' strokeWidth={6} />
  </g>
);

export const Scene4: React.FC = () => {
  const frame = useCurrentFrame();
  const g = frame + F;
  const t = g / FPS;
  const talk = speakerAt(g);
  const bp = Math.min(usePop(L(119.0)), 1);
  const flashA = t >= 80.44 && t < 87.68;
  const flashB = t >= 87.68 && t < 92.44;
  const tMood = t < 92.44 ? 'hurt' : t < 94 ? 'angry' : t < 98 ? 'hurt' : t < 114.48 ? 'neutral' : 'surprised';
  const rMood = t < 98.68 ? 'tired' : t < 114.48 ? 'sad' : 'surprised';
  const tY = interpolate(frame, [L(106.2), L(107.4)], [360, 300], C);
  const px = interpolate(frame, [L(101.3), L(102.7)], [1230, 930], C);
  const bagRot = interpolate(frame, [L(111.0), L(113.5)], [0, -70], C);
  const jx = interpolate(frame, [L(114.0), L(115.5)], [1590, 1470], C);
  const jy = interpolate(frame, [L(114.0), L(115.5)], [800, 985], C);
  const jr = interpolate(frame, [L(114.0), L(115.5)], [0, -55], C);
  return (
    <>
      <Shake on={t >= 114.5 && t < 116.5}>
        <RestaurantBG />
        <Stage>
          <Person kind='tithi' x={620} y={tY} scale={1.5} mood={tMood} talking={talk === 'tithi'} tremble={t >= 92.44 && t < 98} />
          <Person kind='rafi' x={1330} y={360} scale={1.5} flip mood={rMood} tremble={t >= 114.5} />
          <TableFront melt={0.9} glass />
          {t >= 99.4 && (
            <g>
              <rect x={px} y={582} width={42} height={68} rx={9} fill='#333333' stroke='#222' strokeWidth={2.5} />
              <rect x={px + 5} y={589} width={32} height={50} rx={4} fill='#6EC1E4' />
            </g>
          )}
          <Bag rot={bagRot} />
          {t >= 114.0 && <Jacket x={jx} y={jy} scale={0.8} rot={jr} />}
        </Stage>
        <AbsoluteFill style={{background: 'rgba(40,60,110,0.22)'}} />
        {t >= 97.5 && t < 100.5 && <IconPop emoji='💔' x={1000} y={170} size={150} start={L(97.5)} />}
      </Shake>

      {flashA && (
        <>
          <AbsoluteFill style={{background: DARK}} />
          <Pill text='ফ্ল্যাশব্যাক' start={L(80.5)} />
          <Node x={90} icon='📅' label='মঙ্গলবার দুপুর' start={L(81.0)} />
          {t >= 82.4 && <Arrow x={430} start={L(82.4)} />}
          <Node x={540} icon='🏫' label='স্কুল থেকে' start={L(82.6)} />
          {t >= 83.5 && <Arrow x={880} start={L(83.5)} />}
          <Node x={990} icon='🏢' label='রাফির অফিস' start={L(83.7)} />
          {t >= 85.8 && <Arrow x={1330} start={L(85.8)} />}
          <Node x={1440} icon='🎁' label='চমক দেবে বলে' start={L(86.0)} />
        </>
      )}

      {flashB && (
        <>
          <AbsoluteFill style={{background: DARK}} />
          <Pill text='অফিসের গেট' start={L(87.8)} />
          <IconPop emoji='🏢' x={230} y={260} size={380} start={L(87.8)} />
          <IconPop emoji='💂' x={760} y={370} size={250} start={L(88.2)} />
          {t >= 89.1 && <NoteCard text='রাফি স্যার দুই মাস আগেই চলে গেছেন' x={1060} y={330} start={L(89.1)} w={640} />}
        </>
      )}

      {t >= 119.0 && (
        <>
          <AbsoluteFill style={{background: 'rgba(0,0,0,0.5)'}} />
          <Stage><Jacket x={960} y={520} scale={3.2 * bp} rot={-4} /></Stage>
        </>
      )}

      <DialogueLayer from={F} pos={{tithi: {x: 560, y: 250, side: 'left'}, rafi: {x: 1330, y: 250, side: 'right'}}} />
      <Caption g={g} hidden={!!talk || flashA || flashB || t >= 119.0} />
    </>
  );
};
