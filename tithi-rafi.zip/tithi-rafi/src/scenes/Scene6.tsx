import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';
import {Person} from '../characters';
import {RestaurantBG, TableFront, Stage} from './common';
import {Pill, IconPop, Caption, DialogueLayer, speakerAt, usePop, FONT} from '../ui';
import {SCENES, FPS} from '../timing';

const F = SCENES.s6.from;
const DUR = SCENES.s6.to - F;
const L = (s: number) => Math.round(s * FPS) - F;
const C = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const DARK = 'radial-gradient(circle at 50% 40%, #2E3F6E, #151B33)';

const Fade: React.FC<{at: number; children: React.ReactNode}> = ({at, children}) => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{opacity: interpolate(frame, [at, at + 10], [0, 1], C)}}>{children}</AbsoluteFill>;
};

const Item: React.FC<{y: number; icon: string; title: string; sub: string; start: number}> = ({y, icon, title, sub, start}) => {
  const p = usePop(start);
  const k = usePop(start + 22);
  return (
    <div style={{position: 'absolute', left: 300, top: y, width: 1320, height: 260, background: '#FFFFFF', border: '5px solid #222', borderRadius: 36, display: 'flex', alignItems: 'center', gap: 40, padding: '0 50px', boxSizing: 'border-box', fontFamily: FONT, transform: `scale(${p})`, boxShadow: '0 12px 0 rgba(0,0,0,0.3)'}}>
      <div style={{fontSize: 140}}>{icon}</div>
      <div style={{flex: 1}}>
        <div style={{fontSize: 76, fontWeight: 700, color: '#222'}}>{title}</div>
        <div style={{fontSize: 46, fontWeight: 600, color: '#555'}}>{sub}</div>
      </div>
      <div style={{fontSize: 120, transform: `scale(${k})`}}>✅</div>
    </div>
  );
};

const JacketOn: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => {
  const frame = useCurrentFrame();
  const fl = Math.sin(frame / 14) * 4;
  return (
    <g transform={`translate(${x} ${y + fl}) scale(${s})`}>
      <rect x={-104} y={100} width={34} height={130} rx={17} fill='#F26B1D' stroke='#222' strokeWidth={2.5} transform='rotate(6 -87 100)' />
      <rect x={70} y={100} width={34} height={130} rx={17} fill='#F26B1D' stroke='#222' strokeWidth={2.5} transform='rotate(-6 87 110)' />
      <rect x={-70} y={90} width={140} height={180} rx={40} fill='#F26B1D' stroke='#222' strokeWidth={2.5} />
      <path d='M-22 90 L0 130 L22 90' fill='#D9560F' stroke='#222' strokeWidth={2.5} />
      <line x1={0} y1={130} x2={0} y2={270} stroke='#222' strokeWidth={2.5} />
    </g>
  );
};

const Scale: React.FC = () => {
  const frame = useCurrentFrame();
  const a = interpolate(frame, [L(190.5), L(191.5), L(193.2), L(194.6)], [0, -4, -4, 9], C);
  const r = (a * Math.PI) / 180;
  const lx = 960 - 420 * Math.cos(r);
  const ly = 300 - 420 * Math.sin(r);
  const rx = 960 + 420 * Math.cos(r);
  const ry = 300 + 420 * Math.sin(r);
  const pl = Math.min(usePop(L(188.9)), 1);
  const pr = Math.min(usePop(L(190.5)), 1);
  const pan = (x: number, y: number, emoji: string, label: string, p: number, size: number) => (
    <g opacity={p}>
      <line x1={x} y1={y} x2={x - 150} y2={y + 230} stroke='#222' strokeWidth={4} />
      <line x1={x} y1={y} x2={x + 150} y2={y + 230} stroke='#222' strokeWidth={4} />
      <text x={x} y={y + 215} textAnchor='middle' fontSize={size}>{emoji}</text>
      <path d={`M${x - 190} ${y + 230} Q${x} ${y + 340} ${x + 190} ${y + 230} Z`} fill='#E4572E' stroke='#222' strokeWidth={4} />
      <text x={x} y={y + 410} textAnchor='middle' fontSize={46} fontWeight={700} fill='#FFFFFF' fontFamily={FONT}>{label}</text>
    </g>
  );
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
      <rect x={900} y={780} width={120} height={30} rx={10} fill='#8A93B2' stroke='#222' strokeWidth={3} />
      <rect x={950} y={300} width={20} height={490} fill='#8A93B2' stroke='#222' strokeWidth={3} />
      <line x1={lx} y1={ly} x2={rx} y2={ry} stroke='#FFD166' strokeWidth={14} strokeLinecap='round' />
      <circle cx={960} cy={300} r={26} fill='#FFD166' stroke='#222' strokeWidth={3} />
      {pan(lx, ly, '🎒', 'একা টানা বোঝা', pl, 120)}
      {pan(rx, ry, '🪨', 'লুকিয়ে রাখার ভার', pr, 170)}
    </svg>
  );
};

export const Scene6: React.FC = () => {
  const frame = useCurrentFrame();
  const g = frame + F;
  const t = g / FPS;
  const talk = speakerAt(g);
  const q1 = interpolate(frame, [L(197.0), L(197.0) + 14], [0, 1], C);
  const q2 = interpolate(frame, [L(199.3), L(199.3) + 14], [0, 1], C);
  const q3 = interpolate(frame, [L(201.6), L(201.6) + 14], [0, 1], C);
  const slideX = interpolate(frame, [L(165.4), L(167.6)], [760, 1190], C);
  return (
    <>
      {t < 170.2 && (
        <>
          <RestaurantBG />
          <Stage>
            <Person kind='tithi' x={620} y={360} scale={1.5} mood={t < 163.3 ? 'sad' : 'happy'} talking={talk === 'tithi'} />
            <Person kind='rafi' x={1330} y={360} scale={1.5} flip mood={t < 168.8 ? 'sad' : 'happy'} talking={talk === 'rafi'} />
            <TableFront melt={0.9} lit={t < 168.8} glass />
          </Stage>
          <AbsoluteFill style={{background: 'rgba(255,190,90,0.14)'}} />
          {t >= 165.4 && t < 167.6 && <div style={{position: 'absolute', left: slideX, top: 440, fontSize: 90}}>🕯️</div>}
          {t >= 168.8 && <IconPop emoji='💨' x={1100} y={330} size={110} start={L(168.8)} />}
        </>
      )}

      {t >= 169.8 && t < 179.9 && (
        <Fade at={L(169.8)}>
          <AbsoluteFill style={{background: DARK}} />
          <Pill text='তিথির পরিকল্পনা' start={L(170.2)} />
          <Item y={250} icon='📝' title='চাকরির আবেদন' sub='স্কুল ছুটির পর, রাফির সঙ্গে বসে' start={L(172.0)} />
          <Item y={560} icon='🚶' title='লেকের ধারে হাঁটা' sub='যেদিন রাফির ছুটি' start={L(176.0)} />
        </Fade>
      )}

      {t >= 179.5 && t < 188.7 && (
        <Fade at={L(179.5)}>
          <AbsoluteFill style={{background: 'linear-gradient(#FFD9A0, #FFF1D6)'}} />
          <div style={{position: 'absolute', left: 1500, top: 90, width: 190, height: 190, borderRadius: '50%', background: '#FFB703', border: '5px solid #222'}} />
          <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
            <path d='M0 820 Q240 780 480 820 T960 820 T1440 820 T1920 820 V1080 H0 Z' fill='#7FC8D9' stroke='#222' strokeWidth={2.5} />
          </svg>
          <Stage>
            <Person kind='tithi' x={700} y={400} scale={0.9} mood='happy' armUp />
            <Person kind='rafi' x={1000} y={400} scale={0.9} mood='happy' />
            <JacketOn x={1000} y={400} s={0.9} />
          </Stage>
          <Pill text='পরের শুক্রবার • ধানমন্ডি লেক' start={L(179.7)} />
          {t >= 186.0 && <IconPop emoji='🥜' x={800} y={470} size={80} start={L(186.0)} />}
          {t >= 184.0 && <IconPop emoji='💛' x={850} y={250} size={90} start={L(184.0)} />}
        </Fade>
      )}

      {t >= 188.3 && t < 197.3 && (
        <Fade at={L(188.3)}>
          <AbsoluteFill style={{background: DARK}} />
          <Scale />
        </Fade>
      )}

      {t >= 197.0 && (
        <Fade at={L(197.0)}>
          <AbsoluteFill style={{background: DARK}} />
          <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontFamily: FONT, textAlign: 'center', padding: '0 160px'}}>
            <div style={{fontSize: 240, color: '#FFD166', lineHeight: 0.6, height: 120}}>“</div>
            <div style={{fontSize: 78, color: '#FFFFFF', fontWeight: 600, opacity: q1}}>ভালো খবরের ভাগ তো সবাই দেয়।</div>
            <div style={{fontSize: 84, color: '#FFFFFF', fontWeight: 700, marginTop: 30, opacity: q2}}>
              ভালোবাসা বোঝা যায় তখন, যখন <span style={{color: '#FF9AA2'}}>খারাপ খবরটাও</span> কেউ কাউকে বলতে পারে।
            </div>
          </div>
          <div style={{position: 'absolute', left: 0, right: 0, bottom: 110, textAlign: 'center', fontFamily: FONT, fontSize: 52, fontWeight: 700, color: '#FFD166', opacity: q3}}>
            আপনি কি প্রিয় মানুষকে খারাপ খবরটাও বলতে পারেন?
          </div>
        </Fade>
      )}

      <DialogueLayer from={F} pos={{tithi: {x: 560, y: 250, side: 'left'}, rafi: {x: 1330, y: 250, side: 'right'}}} />
      <Caption g={g} hidden={!!talk || (t >= 169.8 && t < 179.5) || t >= 188.3} />
      <AbsoluteFill style={{background: '#000', opacity: interpolate(frame, [DUR - 24, DUR], [0, 1], C)}} />
    </>
  );
};
