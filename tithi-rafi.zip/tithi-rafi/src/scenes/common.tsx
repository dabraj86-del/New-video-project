import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';

export const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>{children}</svg>
);

export const RestaurantBG: React.FC = () => (
  <AbsoluteFill style={{background: '#C98B5A'}}>
    <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: '68%', background: 'linear-gradient(#FBE6BE, #F2C98A)'}} />
    <div style={{position: 'absolute', left: 1280, top: 110, width: 440, height: 340, background: '#BFE3F5', border: '8px solid #222', borderRadius: 16}} />
    <div style={{position: 'absolute', left: 1494, top: 110, width: 8, height: 340, background: '#222'}} />
    <div style={{position: 'absolute', left: 297, top: 0, width: 6, height: 130, background: '#222'}} />
    <div style={{position: 'absolute', left: 237, top: 125, width: 126, height: 70, background: '#FFD166', border: '4px solid #222', borderRadius: '63px 63px 10px 10px'}} />
    <div style={{position: 'absolute', left: 0, right: 0, top: '68%', height: 6, background: '#222'}} />
  </AbsoluteFill>
);

type TableProps = {melt?: number; lit?: boolean; glass?: boolean; glassRot?: number};

export const TableFront: React.FC<TableProps> = ({melt = 0.5, lit = false, glass = false, glassRot = 0}) => {
  const frame = useCurrentFrame();
  const flame = 1 + Math.sin(frame / 3) * 0.15;
  const ch = 70 * (1 - 0.5 * melt);
  const top = 560 - ch;
  return (
    <g>
      <rect x={400} y={650} width={1120} height={430} fill='#A0522D' stroke='#222' strokeWidth={2.5} />
      <rect x={380} y={630} width={1160} height={34} rx={10} fill='#C98B5A' stroke='#222' strokeWidth={2.5} />
      {/* কেকের বাক্স + মোমবাতি */}
      <rect x={880} y={560} width={170} height={70} rx={8} fill='#FFFFFF' stroke='#222' strokeWidth={2.5} />
      <rect x={880} y={560} width={170} height={22} rx={8} fill='#F2A7B8' stroke='#222' strokeWidth={2.5} />
      <rect x={950} y={top} width={14} height={ch} rx={4} fill='#4FC3F7' stroke='#222' strokeWidth={2.5} />
      <ellipse cx={957} cy={562} rx={10 + melt * 16} ry={5} fill='#4FC3F7' stroke='#222' strokeWidth={2} />
      {lit && <path d={`M957 ${top - 6} Q${957 - 12 * flame} ${top - 30} 957 ${top - 50 * flame} Q${957 + 12 * flame} ${top - 30} 957 ${top - 6} Z`} fill='#FF9F1C' stroke='#222' strokeWidth={2} />}
      {/* ঠান্ডা কফির কাপ */}
      <ellipse cx={732} cy={640} rx={52} ry={9} fill='#FFFFFF' stroke='#222' strokeWidth={2.5} />
      <rect x={704} y={590} width={56} height={48} rx={10} fill='#FFFFFF' stroke='#222' strokeWidth={2.5} />
      <rect x={708} y={594} width={48} height={12} rx={5} fill='#6B4226' />
      {/* পানির গ্লাস */}
      {glass && (
        <g transform={`rotate(${glassRot} 1195 636)`}>
          <path d='M1170 570 L1220 570 L1212 636 L1178 636 Z' fill='#BDE7FF' fillOpacity={0.85} stroke='#222' strokeWidth={2.5} />
        </g>
      )}
    </g>
  );
};
