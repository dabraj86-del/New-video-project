import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';

export const Jacket: React.FC<{x: number; y: number; scale?: number; rot?: number}> = ({x, y, scale = 1, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${scale}) translate(-100 -110)`}>
    <rect x={10} y={60} width={46} height={120} rx={22} fill='#F26B1D' stroke='#222' strokeWidth={3} transform='rotate(12 33 60)' />
    <rect x={144} y={60} width={46} height={120} rx={22} fill='#F26B1D' stroke='#222' strokeWidth={3} transform='rotate(-12 167 60)' />
    <rect x={42} y={30} width={116} height={170} rx={22} fill='#F26B1D' stroke='#222' strokeWidth={3} />
    <path d='M82 30 L100 56 L118 30' fill='#D9560F' stroke='#222' strokeWidth={3} />
    <path d='M10 172 l10 12 l6 -14 l10 16 l8 -12 l8 12' fill='none' stroke='#222' strokeWidth={3} />
    <text x={100} y={108} textAnchor='middle' fontSize={24} fontWeight={700} fill='#FFFFFF' fontFamily='Arial, sans-serif'>Quick</text>
    <text x={100} y={136} textAnchor='middle' fontSize={22} fontWeight={700} fill='#FFFFFF' fontFamily='Arial, sans-serif'>Delivery</text>
  </g>
);

export const Zoom: React.FC<{children: React.ReactNode; to?: number; dur?: number}> = ({children, to = 1.06, dur = 900}) => {
  const frame = useCurrentFrame();
  const s = interpolate(frame, [0, dur], [1, to], {extrapolateRight: 'clamp'});
  return <div style={{position: 'absolute', inset: 0, transform: `scale(${s})`, transformOrigin: '50% 45%'}}>{children}</div>;
};

export const Polish: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, rgba(255,255,255,0.10) 0%, rgba(0,0,0,0) 45%, rgba(20,10,10,0.38) 100%)'}} />
  </AbsoluteFill>
);
