import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Person} from '../characters';
import {Stage} from './common';
import {Pill, IconPop, Stamp, NoteCard, Caption, usePop, FONT} from '../ui';
import {SCENES, FPS} from '../timing';

const F = SCENES.s2.from;
const L = (s: number) => Math.round(s * FPS) - F;
const D = ['০', '১', '২'];

const Card: React.FC<{x: number; y: number; icon: string; title: string; sub: string; start: number; bg: string}> = ({x, y, icon, title, sub, start, bg}) => {
  const p = usePop(start);
  return (
    <div style={{position: 'absolute', left: x, top: y, width: 640, height: 420, background: bg, border: '5px solid #222', borderRadius: 36, transform: `scale(${p})`, fontFamily: FONT, textAlign: 'center', padding: 30, boxSizing: 'border-box', boxShadow: '0 12px 0 rgba(0,0,0,0.25)'}}>
      <div style={{fontSize: 140}}>{icon}</div>
      <div style={{fontSize: 76, fontWeight: 700, color: '#222'}}>{title}</div>
      <div style={{fontSize: 46, fontWeight: 600, color: '#333', marginTop: 10}}>{sub}</div>
    </div>
  );
};

const Day: React.FC<{i: number; crossAt: number}> = ({i, crossAt}) => {
  const frame = useCurrentFrame();
  const p = usePop(L(43.0) + i * 6);
  const c = usePop(crossAt);
  const crossed = frame >= crossAt;
  return (
    <div style={{position: 'absolute', left: 330 + i * 330, top: 340, width: 280, height: 300, background: '#FFFFFF', border: '5px solid #222', borderRadius: 28, transform: `scale(${p})`, opacity: crossed ? 0.55 : 1, textAlign: 'center', fontFamily: FONT, boxShadow: '0 10px 0 rgba(0,0,0,0.3)'}}>
      <div style={{background: '#E4572E', color: '#fff', fontSize: 52, fontWeight: 700, borderRadius: '22px 22px 0 0', padding: '8px 0'}}>শুক্র</div>
      <div style={{fontSize: 120, marginTop: 20}}>🥜</div>
      {crossed && <div style={{position: 'absolute', left: 0, right: 0, top: 40, fontSize: 260, fontWeight: 700, color: '#D62828', lineHeight: 1, transform: `scale(${Math.min(c, 1)})`}}>✗</div>}
    </div>
  );
};

export const Scene2: React.FC = () => {
  const frame = useCurrentFrame();
  const g = frame + F;
  const t = g / FPS;
  const cp = usePop(L(24.64));
  const digit = Math.max(0, Math.min(2, Math.floor((frame - L(24.64)) / 12)));
  const lake = t >= 34.66 && t < 42.0;
  const calendar = t >= 42.0;
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 40%, #2E3F6E, #151B33)'}} />

      {/* ২ বছর কাউন্টার */}
      {t >= 24.64 && t < 27.4 && (
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontFamily: FONT, color: '#fff', transform: `scale(${cp})`}}>
          <div style={{fontSize: 300, fontWeight: 700}}>{D[digit]} <span style={{fontSize: 180}}>বছর</span></div>
          <div style={{fontSize: 70}}>❤️ তিথি আর রাফির সম্পর্ক</div>
        </div>
      )}

      {/* দুই পরিচয় কার্ড */}
      {t >= 27.42 && t < 34.5 && (
        <>
          <Card x={220} y={230} icon='👩‍🏫' title='তিথি' sub='মিরপুরের স্কুলে শিক্ষিকা' start={L(28.3)} bg='#FFE08A' />
          <Card x={1060} y={230} icon='💼' title='রাফি' sub='মার্কেটিংয়ে চাকরি' start={L(30.56)} bg='#BFD7FF' />
          {t >= 32.68 && <Stamp text='অন্তত তিথি এটাই জানে' x={520} y={760} start={L(32.68)} rot={-4} />}
        </>
      )}

      {/* ধানমন্ডি লেক */}
      {lake && (
        <>
          <AbsoluteFill style={{background: 'linear-gradient(#9AD8F0, #E8F7FB)', opacity: Math.min(1, (frame - L(34.66)) / 12)}} />
          <div style={{position: 'absolute', left: 1500, top: 90, width: 190, height: 190, borderRadius: '50%', background: '#FFD166', border: '5px solid #222'}} />
          <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
            <path d='M0 820 Q240 780 480 820 T960 820 T1440 820 T1920 820 V1080 H0 Z' fill='#5BC0DE' stroke='#222' strokeWidth={2.5} />
          </svg>
          <Stage>
            <Person kind='tithi' x={640} y={400} scale={0.9} mood='happy' />
            <Person kind='rafi' x={960} y={400} scale={0.9} mood='happy' />
          </Stage>
          <Pill text='ধানমন্ডি লেক' start={L(36.0)} />
          {t >= 35.4 && <NoteCard text='প্রতি শুক্রবার বিকেল' x={1150} y={330} start={L(35.4)} w={520} />}
          {t >= 38.62 && <IconPop emoji='🥜' x={1300} y={620} size={190} start={L(38.62)} />}
        </>
      )}

      {/* বন্ধ হয়ে যাওয়া শুক্রবার */}
      {calendar && (
        <>
          <Pill text='দুই মাস ধরে বন্ধ' x={60} y={50} color='#FF9AA2' start={L(42.0)} />
          {[0, 1, 2, 3].map((i) => <Day key={i} i={i} crossAt={L(43.7) + i * 27} />)}
          {t >= 46.9 && <NoteCard text='অফিসে কাজ পড়ে গেছে' x={700} y={740} start={L(46.9)} w={520} />}
        </>
      )}

      <Caption g={g} hidden={t >= 24.64} />
    </>
  );
};
