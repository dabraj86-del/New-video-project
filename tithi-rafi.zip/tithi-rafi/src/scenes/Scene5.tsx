import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';
import {Person} from '../characters';
import {RestaurantBG, TableFront, Stage} from './common';
import {Jacket, Zoom} from './props';
import {IconPop, Caption, DialogueLayer, speakerAt, usePop, FONT} from '../ui';
import {SCENES, FPS} from '../timing';

const F = SCENES.s5.from;
const L = (s: number) => Math.round(s * FPS) - F;
const C = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const CakeLid: React.FC<{start: number}> = ({start}) => {
  const p = usePop(start);
  return (
    <div style={{position: 'absolute', left: 230, top: 270, width: 560, height: 400, background: '#FFFFFF', border: '6px solid #222', borderRadius: 40, transform: `rotate(-4deg) scale(${p})`, textAlign: 'center', fontFamily: FONT, boxShadow: '0 14px 0 rgba(0,0,0,0.3)'}}>
      <div style={{fontSize: 90, marginTop: 24}}>🎂</div>
      <div style={{fontSize: 130, fontWeight: 700, color: '#1F4FD8', fontStyle: 'italic'}}>তিথি</div>
    </div>
  );
};

const Blister: React.FC<{start: number}> = ({start}) => {
  const p = usePop(start);
  return (
    <div style={{position: 'absolute', left: 1130, top: 270, width: 560, height: 400, background: '#FFE9D6', border: '6px solid #222', borderRadius: 40, transform: `rotate(3deg) scale(${p})`, textAlign: 'center', fontFamily: FONT, boxShadow: '0 14px 0 rgba(0,0,0,0.3)'}}>
      <div style={{fontSize: 220, marginTop: 70}}>🤚</div>
      {[[200, 150], [250, 120], [300, 165]].map(([x, y], i) => (
        <div key={i} style={{position: 'absolute', left: x, top: y, width: 22, height: 22, borderRadius: '50%', background: '#C97B5A', border: '3px solid #222'}} />
      ))}
    </div>
  );
};

export const Scene5: React.FC = () => {
  const frame = useCurrentFrame();
  const g = frame + F;
  const t = g / FPS;
  const talk = speakerAt(g);
  const cardsOn = t >= 143.8 && t < 152.6;
  const tMood = t < 124.06 ? 'surprised' : t < 140.34 ? 'hurt' : t < 157.52 ? 'sad' : 'hurt';
  const rMood = t < 129.38 ? 'tired' : 'sad';
  const tY = interpolate(frame, [L(140.6), L(142.2)], [300, 360], C);

  const inHands = t >= 123.4 && t < 129.38;
  const jx = interpolate(frame, [L(123.4), L(124.4)], [1470, 1170], C);
  const jy = interpolate(frame, [L(123.4), L(124.4)], [985, 520], C);
  const wobble = t >= 125.0 ? Math.sin((frame - L(125.0)) / 4) * 14 : 0;
  const jr = interpolate(frame, [L(123.4), L(124.4)], [-55, 0], C) + wobble;

  return (
    <>
      <Zoom to={1.06} dur={Math.round(37.3 * FPS)}>
        <RestaurantBG />
        <Stage>
          <Person kind='tithi' x={620} y={tY} scale={1.5} mood={tMood} talking={talk === 'tithi'} />
          <Person kind='rafi' x={1330} y={360} scale={1.5} flip mood={rMood} talking={talk === 'rafi'} tremble={t >= 124.06 && t < 129.38} />
          <TableFront melt={0.9} lit={t >= 156.9} glass />
          {t < 123.4 && <Jacket x={1470} y={985} scale={0.8} rot={-55} />}
          {inHands && <Jacket x={jx} y={jy} scale={0.8} rot={jr} />}
          {t >= 129.38 && <Jacket x={1130} y={590} scale={0.55} rot={-8} />}
        </Stage>
        <AbsoluteFill style={{background: 'rgba(40,60,110,0.18)'}} />

        {t >= 129.5 && t < 131.5 && <IconPop emoji='📄' x={1500} y={330} size={120} start={L(129.5)} />}
        {t >= 155.3 && t < 156.8 && <IconPop emoji='🔥' x={905} y={470} size={90} start={L(155.3)} />}
      </Zoom>

      {t >= 131.8 && t < 136.2 && (
        <>
          <IconPop emoji='👔' x={80} y={60} size={100} start={L(131.8)} />
          {t >= 132.6 && <IconPop emoji='➜' x={230} y={70} size={90} start={L(132.6)} />}
          {t >= 133.2 && <IconPop emoji='🎒' x={340} y={60} size={100} start={L(133.2)} />}
          {t >= 134.0 && <IconPop emoji='➜' x={490} y={70} size={90} start={L(134.0)} />}
          {t >= 134.4 && <IconPop emoji='🛵' x={600} y={60} size={100} start={L(134.4)} />}
        </>
      )}

      {cardsOn && <AbsoluteFill style={{background: 'rgba(0,0,0,0.38)'}} />}
      {t >= 143.8 && t < 152.6 && <CakeLid start={L(143.8)} />}
      {t >= 147.0 && t < 152.6 && <Blister start={L(147.0)} />}

      <DialogueLayer from={F} pos={{tithi: {x: 560, y: 250, side: 'left'}, rafi: {x: 1330, y: 250, side: 'right'}}} />
      <Caption g={g} hidden={!!talk || cardsOn} />
    </>
  );
};
