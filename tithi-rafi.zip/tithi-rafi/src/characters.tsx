import React from 'react';
import {useCurrentFrame} from 'remotion';

const OUT = '#222222';
const SW = 2.5;

export type Mood = 'neutral' | 'angry' | 'sad' | 'hurt' | 'surprised' | 'tired' | 'happy';
export type Kind = 'tithi' | 'rafi' | 'waiter';

type Props = {
  kind: Kind;
  mood?: Mood;
  talking?: boolean;
  x?: number;
  y?: number;
  scale?: number;
  flip?: boolean;
  tremble?: boolean;
  showJacket?: boolean;
  armUp?: boolean;
};

const SKIN: Record<Kind, string> = {tithi: '#C98F62', rafi: '#E0A878', waiter: '#D9A074'};
const TOP: Record<Kind, string> = {tithi: '#F6E27A', rafi: '#8FB0E6', waiter: '#F4F4F4'};
const HAIR = '#1B1213';

export const Person: React.FC<Props> = ({
  kind, mood = 'neutral', talking = false, x = 0, y = 0, scale = 1,
  flip = false, tremble = false, showJacket = false, armUp = false,
}) => {
  const frame = useCurrentFrame();
  const float = Math.sin(frame / 14) * 4;
  const shake = tremble ? Math.sin(frame * 2.2) * 2.5 : 0;
  const blink = frame % 96 > 90;
  const mouthStep = talking ? Math.floor(frame / 5) % 3 : 0;
  const skin = SKIN[kind];

  const browAngle = mood === 'angry' ? 14 : mood === 'sad' || mood === 'hurt' ? -12 : 0;
  const browY = mood === 'surprised' ? -8 : 0;
  const tear = mood === 'sad' || mood === 'hurt';

  return (
    <g transform={`translate(${x + shake} ${y + float}) scale(${flip ? -scale : scale} ${scale})`}>
      {/* legs */}
      <rect x={-45} y={250} width={34} height={120} rx={17} fill="#2B2B33" stroke={OUT} strokeWidth={SW} />
      <rect x={11} y={250} width={34} height={120} rx={17} fill="#2B2B33" stroke={OUT} strokeWidth={SW} />
      <ellipse cx={-30} cy={374} rx={30} ry={13} fill="#4a3b30" stroke={OUT} strokeWidth={SW} />
      <ellipse cx={30} cy={374} rx={30} ry={13} fill="#4a3b30" stroke={OUT} strokeWidth={SW} />

      {/* body */}
      <rect x={-70} y={90} width={140} height={180} rx={40} fill={TOP[kind]} stroke={OUT} strokeWidth={SW} />
      {kind === 'tithi' && (
        <>
          <path d="M-70 120 Q0 230 70 120 L70 150 Q0 270 -70 150 Z" fill="#FFFFFF" stroke={OUT} strokeWidth={SW} />
        </>
      )}
      {kind === 'rafi' && (
        <>
          <path d="M-22 90 L0 130 L22 90" fill="#A9C3EE" stroke={OUT} strokeWidth={SW} />
          <ellipse cx={-30} cy={150} rx={16} ry={10} fill="#7C98CC" opacity={0.5} />
        </>
      )}
      {kind === 'waiter' && <rect x={-45} y={170} width={90} height={100} rx={14} fill="#222" />}

      {/* arms */}
      <rect x={-104} y={100} width={34} height={130} rx={17} fill={TOP[kind]} stroke={OUT} strokeWidth={SW} transform="rotate(6 -87 100)" />
      <g transform={armUp ? 'rotate(-70 87 110)' : 'rotate(-6 87 110)'}>
        <rect x={70} y={100} width={34} height={130} rx={17} fill={TOP[kind]} stroke={OUT} strokeWidth={SW} />
        <circle cx={87} cy={236} r={16} fill={skin} stroke={OUT} strokeWidth={SW} />
      </g>
      <circle cx={-87} cy={236} r={16} fill={skin} stroke={OUT} strokeWidth={SW} />

      {/* backpack + jacket for rafi */}
      {kind === 'rafi' && (
        <g>
          <rect x={-100} y={110} width={46} height={110} rx={14} fill="#222" stroke={OUT} strokeWidth={SW} />
          {showJacket && <path d="M-98 112 L-58 108 L-62 150 L-90 146 Z" fill="#F26B1D" stroke={OUT} strokeWidth={SW} />}
        </g>
      )}
      {kind === 'tithi' && <rect x={52} y={110} width={26} height={110} rx={8} fill="#7A4A2B" stroke={OUT} strokeWidth={SW} />}

      {/* neck + head */}
      <rect x={-14} y={70} width={28} height={30} rx={10} fill={skin} stroke={OUT} strokeWidth={SW} />
      {kind === 'tithi' && <path d="M-66 -10 Q-76 120 -50 130 L-40 20 Z M66 -10 Q76 120 50 130 L40 20 Z" fill={HAIR} stroke={OUT} strokeWidth={SW} />}
      <ellipse cx={0} cy={20} rx={58} ry={66} fill={skin} stroke={OUT} strokeWidth={SW} />
      {kind === 'tithi' && <path d="M-60 20 Q-62 -60 0 -56 Q62 -60 60 20 Q40 -22 0 -24 Q-40 -22 -60 20 Z" fill={HAIR} stroke={OUT} strokeWidth={SW} />}
      {kind === 'rafi' && (
        <>
          <path d="M-62 14 Q-70 -62 0 -66 Q70 -62 62 14 Q50 -30 20 -26 Q-10 -40 -62 14 Z" fill={HAIR} stroke={OUT} strokeWidth={SW} />
          <path d="M-34 58 Q0 92 34 58 Q0 74 -34 58 Z" fill="#2A2020" opacity={0.7} />
        </>
      )}
      {kind === 'waiter' && <path d="M-58 8 Q-60 -52 0 -50 Q60 -52 58 8 Q40 -20 0 -20 Q-40 -20 -58 8 Z" fill={HAIR} stroke={OUT} strokeWidth={SW} />}
      {kind === 'tithi' && (
        <>
          <circle cx={-58} cy={34} r={4} fill="#fff" stroke={OUT} strokeWidth={1.5} />
          <circle cx={58} cy={34} r={4} fill="#fff" stroke={OUT} strokeWidth={1.5} />
        </>
      )}

      {/* eyes */}
      {blink ? (
        <>
          <line x1={-34} y1={20} x2={-12} y2={20} stroke={OUT} strokeWidth={3} />
          <line x1={12} y1={20} x2={34} y2={20} stroke={OUT} strokeWidth={3} />
        </>
      ) : (
        <>
          <ellipse cx={-23} cy={20} rx={9} ry={mood === 'surprised' ? 13 : 10} fill="#fff" stroke={OUT} strokeWidth={2} />
          <ellipse cx={23} cy={20} rx={9} ry={mood === 'surprised' ? 13 : 10} fill="#fff" stroke={OUT} strokeWidth={2} />
          <circle cx={-22} cy={21} r={5} fill="#3A2418" />
          <circle cx={24} cy={21} r={5} fill="#3A2418" />
        </>
      )}
      {/* eyebrows */}
      <line x1={-36} y1={2 + browY} x2={-10} y2={2 + browY} stroke={OUT} strokeWidth={4} strokeLinecap="round" transform={`rotate(${browAngle} -23 2)`} />
      <line x1={10} y1={2 + browY} x2={36} y2={2 + browY} stroke={OUT} strokeWidth={4} strokeLinecap="round" transform={`rotate(${-browAngle} 23 2)`} />
      {tear && <path d="M-27 34 Q-31 46 -23 46 Q-17 44 -27 34 Z" fill="#7EC8F0" stroke={OUT} strokeWidth={1.5} />}

      {/* nose */}
      <path d="M-3 30 Q0 40 5 38" fill="none" stroke={OUT} strokeWidth={2} />

      {/* mouth: 0 closed, 1 small, 2 big */}
      {mouthStep === 0 && (
        <path d={mood === 'happy' ? 'M-16 54 Q0 68 16 54' : mood === 'angry' || mood === 'sad' || mood === 'hurt' ? 'M-14 62 Q0 52 14 62' : 'M-14 58 L14 58'} fill="none" stroke={OUT} strokeWidth={3} strokeLinecap="round" />
      )}
      {mouthStep === 1 && <ellipse cx={0} cy={58} rx={10} ry={6} fill="#8A2F3A" stroke={OUT} strokeWidth={2.5} />}
      {mouthStep === 2 && <ellipse cx={0} cy={60} rx={13} ry={12} fill="#8A2F3A" stroke={OUT} strokeWidth={2.5} />}
    </g>
  );
};
