import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {SCENES} from './timing';
import {CueProvider} from './ui';
import {Polish} from './scenes/props';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Scene5} from './scenes/Scene5';
import {Scene6} from './scenes/Scene6';

const LIST: {s: {from: number; to: number}; C: React.FC}[] = [
  {s: SCENES.s1, C: Scene1},
  {s: SCENES.s2, C: Scene2},
  {s: SCENES.s3, C: Scene3},
  {s: SCENES.s4, C: Scene4},
  {s: SCENES.s5, C: Scene5},
  {s: SCENES.s6, C: Scene6},
];

export const Video: React.FC = () => (
  <CueProvider>
    <AbsoluteFill style={{background: '#000'}}>
      {LIST.map(({s, C}, i) => (
        <Sequence key={i} from={s.from} durationInFrames={s.to - s.from}>
          <C />
        </Sequence>
      ))}
      <Polish />
      <Audio src={staticFile('voice.mp3')} />
    </AbsoluteFill>
  </CueProvider>
);
