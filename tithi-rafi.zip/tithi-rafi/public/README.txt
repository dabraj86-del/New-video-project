এই ফোল্ডারে দুটো ফাইল রাখুন:
  voice.mp3  (ElevenLabs অডিও)
  subs.srt   (ElevenLabs SRT)
