import {loadFont} from '@remotion/google-fonts/HindSiliguri';
const {fontFamily} = loadFont('normal', {weights: ['500', '700'], subsets: ['bengali', 'latin']});
export const FONT = fontFamily;
