import React from 'react';
import {CO, ST, SC} from './data';
import {FONT} from './font';
import {Scene, useT, ez, kf, back, Bubble, Thought, StampB, Badge, LocPill, Pop, Wipe, Cam} from './UI';
import {Char, Brush} from './Characters';
import {Bathroom, LivingRoom, SofaFront, Yard, Shop, ShopCounter, CleanBG} from './Backgrounds';
import {Ico, HandIco, Drop, Note, Boat, Tank, Bulb, Coin, Bank, Bucket, Mug, TeaCup, Check, Cross, Egg, Bottle, Tooth, Foam, Question} from './Icons';

const cupHand = <HandIco size={70} dy={-34}><TeaCup /></HandIco>;
const brushUp = <g transform="rotate(180)"><Brush /></g>;
const coinHand = <HandIco size={60} dy={-30}><Coin /></HandIco>;
const bottleHand = <HandIco size={120} dy={-66}><Bottle level={1} /></HandIco>;
const inRange = (t: number, c: {s: number; e: number}) => t >= c.s && t <= c.e;

/* ---------- সিন ১ ---------- */
const B1 = () => {
  const t = useT();
  const sing = t > 9.7 && t % 4.6 < 3.2;
  const talk = inRange(t, CO.titu1) || sing;
  const boatX = kf(t, [[22, 1500], [32.6, 430]]);
  return (
    <>
      <Cam shake={[[3.8, 5.2, 6]]}>
        <Bathroom door tapOn water={ez(t, 10, 21)} />
        {t >= 22 && (
          <div style={{position: 'absolute', left: boatX - 85, top: 870 + Math.sin(t * 3) * 8, transform: `rotate(${Math.sin(t * 2) * 4}deg)`}}>
            <Ico size={170}><Boat /></Ico>
          </div>
        )}
        <Char who="titu" x={1000} expr={t < 9 ? 'happy' : 'laugh'} talk={talk} armR={t > 6.4 ? 205 : 12} upR={false} handR={<Brush />} armL={14 + Math.sin(t * 5) * 10} />
        {[10.4, 13.6, 16.8, 20, 23.2, 26.4, 29.6].map((s, i) => (
          <Pop key={i} s={s} e={s + 2.6} x={i % 2 ? 1160 : 840} y={560} size={90} anim="rise"><Note /></Pop>
        ))}
        <Bubble co={CO.mom} x={190} y={270} w={640} tail={0.3} color="#C62828" />
        <Bubble co={CO.titu1} x={1000} y={420} w={780} />
        <Badge s={0.3} x={1000} y={380} name="টিটু" sub="৭ বছর" color="#1E4FD8" />
      </Cam>
      <LocPill s={0.3} text="সকাল · বাথরুম" />
    </>
  );
};

/* ---------- সিন ২ ---------- */
const B2 = () => {
  const t = useT();
  const living = t < 36.8;
  const tx = kf(t, [[36.8, 1050], [44.4, 1050], [45, 1330], [47.2, 1330], [47.9, 1050], [50.6, 1050], [51.8, 520], [52, 520], [53.1, -250]]);
  const walk = (t > 44.4 && t < 45) || (t > 47.2 && t < 47.9) || (t > 50.7 && t < 51.8) || t > 52;
  const pat = t >= 45 && t < 47.3;
  const hasBoat = t >= 51.9;
  const expr = t < 44.8 ? 'think' : t < 47.4 ? 'laugh' : t < 50.7 ? 'proud' : 'happy';
  return (
    <>
      {living ? (
        <>
          <LivingRoom />
          <Char who="dadu" x={1270} expr="happy" armL={-45 - Math.max(0, Math.sin(t * 2.2)) * 22} handL={cupHand} />
          <SofaFront />
          <Badge s={33.1} x={1270} y={300} name="দাদু" sub="৬৫ বছর · শান্ত ও জ্ঞানী" color="#1E4FD8" />
          <LocPill s={33} text="সকাল · ড্রয়িং রুম" />
        </>
      ) : (
        <>
          <Bathroom door water={1} />
          {t < 51.9 && (
            <div style={{position: 'absolute', left: 345, top: 880 + Math.sin(t * 3) * 6}}><Ico size={170}><Boat /></Ico></div>
          )}
          <Char who="dadu" x={1500} flip cane armR={20} armL={-45} handL={cupHand} expr="happy" talk={inRange(t, CO.dadu)} />
          <Char who="titu" x={tx} flip={t > 50.6} walk={walk} expr={expr} talk={inRange(t, CO.titu2)} armR={hasBoat ? -40 : pat ? 70 + Math.sin(t * 10) * 14 : 8} handR={hasBoat ? <HandIco size={100} dy={-50}><Boat /></HandIco> : undefined} />
          <Pop s={38.4} e={44.7} x={680} y={450} size={230} anim="pulse"><Tank level={kf(t, [[38.6, 1], [44.3, 0.05]])} /></Pop>
          <Bubble co={CO.dadu} x={1500} y={320} w={780} tail={0.75} fs={44} />
          <Bubble co={CO.titu2} x={1050} y={430} w={620} />
        </>
      )}
      <Wipe at={36.8} />
      <Wipe at={SC.s2[0]} />
    </>
  );
};

/* ---------- সিন ৩ ---------- */
const B3 = () => {
  const t = useT();
  const tx = kf(t, [[53.1, -220], [57, 1180]]);
  const arrive = t > 57;
  let armR = 12;
  if (t >= 58.8 && t < 60.4) armR = 155 + Math.sin(t * 9) * 8;
  else if (t >= 65.2 && t < 68.4) armR = 150 + Math.sin(t * 22) * 18;
  const expr = t < 60.5 ? 'neutral' : t < 65.1 ? 'surprised' : t < 68.5 ? 'angry' : t < 74.5 ? 'think' : t < 76.3 ? 'panic' : 'sad';
  const foam = kf(t, [[68.8, 0], [72, 1]]);
  const panic = t >= 74.5 && t < 76.3;
  const air = t >= 61.8 && t < 63.6 ? ez(t, 61.8, 1.6) : 0;
  const bx = kf(t, [[76.5, 2250], [78.8, 1650]]);
  return (
    <>
      <Cam shake={[[65.2, 68.4, 5], [74.5, 76.3, 9]]} zoom={[{s: 72.2, e: 76.4, k: 1.14, ox: 1180, oy: 640}]}>
        <Bathroom door tapOn={false} air={air} />
        <Char who="titu" x={tx} walk={!arrive} expr={expr} talk={inRange(t, CO.titu3)} armR={armR} armL={-30} handL={brushUp} foam={foam} santa={t >= 72.6} tremble={panic || (t >= 65.2 && t < 68.4)} />
        {t >= 76.5 && <Char who="baba" x={bx} flip walk={t < 78.8} expr="happy" talk={inRange(t, CO.baba)} armR={-40} handR={cupHand} />}
        <StampB st={ST.air} x={1560} y={400} color="#546E7A" rot={-6} />
        <Bubble co={CO.titu3} x={1180} y={430} w={560} />
        <Bubble co={CO.baba} x={1650} y={300} w={820} tail={0.7} fs={42} color="#2E7D32" />
        <Badge s={76.7} x={1650} y={270} name="বাবা" sub="৩৬ বছর · টিটুর বাবা" color="#2E7D32" />
      </Cam>
      <LocPill s={53.2} text="পরদিন সকাল · বাথরুম" />
      <Wipe at={SC.s3[0]} />
    </>
  );
};

/* ---------- সিন ৪ ---------- */
const B4 = () => {
  const t = useT();
  if (t < 111) {
    const ax = kf(t, [[88.78, 250], [93.4, 1185], [96.3, 1185], [99, 520]]);
    const walk = t < 93.4 || (t > 96.3 && t < 99);
    const lvl = t < 93.5 ? 0 : t < 96.3 ? kf(t, [[93.5, 0], [96.3, 1]]) : t < 99.5 ? 1 : kf(t, [[99.5, 1], [104.2, 0.05]]);
    const scroll = kf(t, [[88.78, 0], [93.4, 700], [96.3, 700], [99, 0]]);
    const looking = t >= 99.5 && t < 105.3;
    const expr = t < 96.3 ? 'happy' : t < 99.5 ? 'proud' : t < 101 ? 'surprised' : t < 105.5 ? 'sad' : 'angry';
    return (
      <>
        <Cam zoom={[{s: 103.2, e: 109, k: 1.12, ox: 520, oy: 700}]}>
          <Yard scroll={scroll} tapPost />
          {t >= 93.5 && t < 96.3 && (
            <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
              <line x1={1342} y1={600} x2={1342} y2={752} stroke="#6EC6FF" strokeWidth={14} strokeDasharray="18 10" strokeDashoffset={-t * 300} />
            </svg>
          )}
          <Char who="titu" x={ax} flip={t > 96.3} walk={walk} expr={expr} foam={1} armR={looking ? 95 + Math.sin(t * 12) * 5 : 40} armL={8} handR={<HandIco size={150} dy={-14}><Bucket level={lvl} hole /></HandIco>} />
          {Array.from({length: 8}).map((_, i) => (
            <Pop key={i} s={99.6 + i * 0.8} e={99.6 + i * 0.8 + 1.2} x={357 + (i % 3) * 14} y={860} size={44} anim="fall"><Drop /></Pop>
          ))}
          <StampB st={ST.hole} x={950} y={380} color="#C62828" rot={-8} />
          <Pop s={104.2} e={110.6} x={1300} y={560} size={300} anim="pulse"><Bucket level={0.05} hole /></Pop>
          <Pop s={109.6} e={111} x={1560} y={540} size={260} anim="pulse"><Bank broken={t > 110.3} /></Pop>
          {[0, 1, 2].map((i) => <Pop key={i} s={110.4 + i * 0.2} e={111} x={1460 + i * 90} y={420} size={80} anim="rise"><Coin /></Pop>)}
        </Cam>
        <Badge s={88.9} x={500} y={420} name="টিটু" sub="" color="#1E4FD8" />
        <Wipe at={SC.s4[0]} />
      </>
    );
  }
  if (t < 122.9) {
    const tx = kf(t, [[111.2, -220], [114, 560]]);
    const rOn = t >= 116 && t < 117.9;
    return (
      <>
        <Shop />
        <Char who="rahim" x={1000} flip expr="happy" talk={inRange(t, CO.rahim)} armR={rOn ? 75 : 10} handR={rOn ? bottleHand : undefined} />
        <ShopCounter />
        <Char who="titu" x={tx} walk={t < 114} expr={t < 117.8 ? 'happy' : 'proud'} foam={1} armR={t < 117.9 ? 60 : -45} armL={t >= 117.9 ? -45 : 8} handR={t < 116.9 ? coinHand : t >= 117.9 ? bottleHand : undefined} />
        <Bubble co={CO.rahim} x={1000} y={310} w={780} tail={0.72} fs={46} color="#1565C0" />
        <Badge s={114.4} x={1000} y={290} name="রহিম" sub="মোড়ের দোকানদার · ৪৫ বছর" color="#1565C0" />
        <LocPill s={111.1} text="মোড়ের দোকান" />
        <Wipe at={111} />
      </>
    );
  }
  const scroll = kf(t, [[122.9, 0], [131, -1600]]);
  return (
    <>
      <Yard scroll={scroll} />
      <Char who="titu" x={960} flip walk expr="proud" foam={1} armR={-45} armL={-45} handR={bottleHand} />
      <Thought s={124.2} e={129.6} x={960} y={430} w={300} h={220}><Ico size={140}><Egg /></Ico></Thought>
      <Wipe at={122.9} />
    </>
  );
};

/* ---------- সিন ৫ ---------- */
const B5 = () => {
  const t = useT();
  const tx = kf(t, [[131, -220], [134, 1100], [147, 1100], [147.9, 1180]]);
  const dx = kf(t, [[140.2, -260], [142.6, 760]]);
  const handedMug = t >= 148;
  const pour = t >= 148.6 && t < 152.5;
  const mugLevel = pour ? kf(t, [[148.6, 0], [151.6, 0.5]]) : t >= 152.5 ? 0.5 : 0;
  const foam = t < 152.6 ? 1 : kf(t, [[152.6, 1], [156.5, 0]]);
  const washing = t >= 153 && t < 156.5;
  const armL = !handedMug ? (t >= 146.8 ? 70 : 8) : washing ? -145 : -45;
  const armR = t >= 159.8 ? 80 : -45;
  const looking = t >= 140.7 && t < 146.8;
  const mx = kf(t, [[158.8, 2250], [160.2, 1650]]);
  const handing = t >= 146.6 && t < 148;
  return (
    <>
      <Bathroom door mug={t < 146.6} />
      {t >= 140.2 && <Char who="dadu" x={dx} walk={t < 142.6} expr="happy" armR={handing ? 55 : 10} handR={handing ? <HandIco size={90} dy={-40}><Mug level={0} /></HandIco> : undefined} />}
      <Char who="titu" x={tx} walk={t < 134} flip={looking} expr={t < 140 ? 'think' : t < 148 ? 'neutral' : t < 152.9 ? 'happy' : 'proud'} foam={foam} talk={inRange(t, CO.titu4)} armL={armL} armR={armR}
        handL={handedMug ? <HandIco size={90} dy={-40}><Mug level={mugLevel} /></HandIco> : undefined}
        handR={<g transform={`rotate(${pour ? -100 : 0})`}>{bottleHand}</g>} />
      {t >= 158.8 && <Char who="ma" x={mx} flip walk={t < 160.2} expr="happy" armL={-30} armR={-30} />}
      <Thought s={135.2} e={140.6} x={1100} y={430} w={560} h={210}>
        <Ico size={110}><Foam /></Ico><Ico size={110}><Tooth /></Ico><Ico size={110}><TeaCup /></Ico>
      </Thought>
      <Pop s={146.9} e={150.4} x={1400} y={430} size={120} anim="float"><Bulb /></Pop>
      <StampB st={ST.half} x={1420} y={380} color="#2E7D32" rot={-5} />
      <Bubble co={CO.titu4} x={1180} y={430} w={620} />
      <Badge s={159.1} x={1650} y={290} name="মা" sub="৩২ বছর · টিটুর মা" color="#C2185B" />
      <LocPill s={131.1} text="বাথরুম" />
      <Wipe at={SC.s5[0]} />
    </>
  );
};

/* ---------- সিন ৬ ---------- */
const B6 = () => {
  const t = useT();
  const tx = kf(t, [[169, -220], [171.6, 1180]]);
  const sing = t >= 172 && t < 181.5 && t % 3.5 < 1.6;
  const closing = t >= 172.6 && t < 174.4;
  const dx = kf(t, [[181.3, -250], [183, 640]]);
  return (
    <>
      <Bathroom door tapOn={t >= 166.8 && t < 173.4} />
      <Pop s={163.4} e={168.9} x={960} y={500} size={320} anim="pulse"><Tank level={kf(t, [[163.6, 0.05], [167.6, 1]])} /></Pop>
      <Pop s={176.5} x={1560} y={576} size={150} anim="none"><Mug level={0.5} /></Pop>
      {t >= 169 && <Char who="titu" x={tx} walk={t < 171.6} expr={t < 176 ? 'happy' : 'laugh'} talk={sing} armR={closing ? 155 : 12} armL={-30} handL={brushUp} />}
      {[172.4, 174.6, 177.6, 179.4].map((s, i) => <Pop key={i} s={s} e={s + 2.4} x={i % 2 ? 1120 : 900} y={580} size={70} anim="rise"><Note /></Pop>)}
      {t >= 181.3 && <Char who="dadu" x={dx} walk={t < 183} expr="happy" armR={-45} handR={cupHand} />}
      <StampB st={ST.off} x={1500} y={400} color="#2E7D32" rot={-5} icon={<Ico size={80}><Check /></Ico>} />
      <LocPill s={162.8} text="দুপুর · বাথরুম" />
      <Wipe at={SC.s6[0]} />
    </>
  );
};

/* ---------- সিন ৭ (ক্লিন মোশন গ্রাফিক্স) ---------- */
const B7 = () => {
  const t = useT();
  const nodes = [
    {s: 188.2, label: 'কল খোলা, গান চলছে', ic: <Note />, c: '#E91E63'},
    {s: 190.6, label: 'পানি বয়ে যায়', ic: <Drop />, c: '#039BE5'},
    {s: 192.8, label: 'ট্যাংক খালি', ic: <Tank level={0.05} />, c: '#607D8B'},
    {s: 195.0, label: 'ফুটো বালতি নিয়ে দৌড়', ic: <Bucket level={0.1} hole />, c: '#FB8C00'},
  ];
  const flowOpacity = 1 - ez(t, 198.3, 0.4);
  const card: React.CSSProperties = {position: 'absolute', background: '#fff', border: '6px solid #222', borderRadius: 40, boxShadow: '0 10px 0 rgba(0,0,0,.18)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontFamily: FONT, fontWeight: 700, textAlign: 'center'};
  const pill = (s: number, left: number, top: number, w: number, h: number, bg: string, color: string, text: string, fs: number) => {
    const p = back(ez(t, s, 0.45));
    return <div style={{...card, left, top, width: w, height: h, background: bg, color, fontSize: fs, transform: `scale(${p})`, padding: '0 20px'}}>{text}</div>;
  };
  return (
    <>
      <CleanBG />
      {t < 198.8 && (
        <div style={{opacity: flowOpacity}}>
          {pill(186.3, 560, 70, 800, 130, '#FFB300', '#222', 'তোমরা কি জানো?', 76)}
          {nodes.map((n, i) => {
            const p = back(ez(t, n.s, 0.5));
            const left = 145 + i * 430;
            return (
              <React.Fragment key={i}>
                <div style={{...card, left, top: 270, width: 340, height: 520, transform: `scale(${p})`}}>
                  <Ico size={200}>{n.ic}</Ico>
                  <div style={{fontSize: 46, color: n.c, marginTop: 20, padding: '0 14px', lineHeight: 1.25}}>{n.label}</div>
                </div>
                {i > 0 && (
                  <svg width={90} height={50} viewBox="0 0 70 40" style={{position: 'absolute', left: left - 90, top: 505, opacity: p}}>
                    <path d="M2 20 H56 M40 6 L58 20 L40 34" fill="none" stroke="#222" strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </React.Fragment>
            );
          })}
        </div>
      )}
      {t >= 198.6 && (
        <>
          <div style={{...card, left: 200, top: 160, width: 640, height: 560, borderColor: '#C62828', transform: `scale(${back(ez(t, 198.8, 0.45))})`}}>
            <div style={{display: 'flex', gap: 10, alignItems: 'center'}}><Ico size={190}><Drop /></Ico><Ico size={110}><Cross /></Ico></div>
            <div style={{fontSize: 60, color: '#C62828', marginTop: 24}}>কল খুলে গান</div>
          </div>
          <div style={{...card, left: 1080, top: 160, width: 640, height: 560, borderColor: '#2E7D32', transform: `scale(${back(ez(t, 199.0, 0.45))})`}}>
            <div style={{display: 'flex', gap: 10, alignItems: 'center'}}><Ico size={190}><Mug level={0.5} /></Ico><Ico size={110}><Check /></Ico></div>
            <div style={{fontSize: 60, color: '#2E7D32', marginTop: 24}}>এক মগ পানি</div>
          </div>
          {pill(199.1, 880, 380, 160, 100, '#222', '#fff', 'বনাম', 46)}
          {pill(199.7, 360, 800, 1200, 140, '#1E4FD8', '#fff', 'কল খুলে গান শোনানোর দরকার নেই', 68)}
        </>
      )}
      <Wipe at={SC.s7[0]} />
    </>
  );
};

export const S1 = () => <Scene from={SC.s1[0]} to={SC.s1[1]}><B1 /></Scene>;
export const S2 = () => <Scene from={SC.s2[0]} to={SC.s2[1]}><B2 /></Scene>;
export const S3 = () => <Scene from={SC.s3[0]} to={SC.s3[1]}><B3 /></Scene>;
export const S4 = () => <Scene from={SC.s4[0]} to={SC.s4[1]}><B4 /></Scene>;
export const S5 = () => <Scene from={SC.s5[0]} to={SC.s5[1]}><B5 /></Scene>;
export const S6 = () => <Scene from={SC.s6[0]} to={SC.s6[1]}><B6 /></Scene>;
export const S7 = () => <Scene from={SC.s7[0]} to={SC.s7[1]}><B7 /></Scene>;
