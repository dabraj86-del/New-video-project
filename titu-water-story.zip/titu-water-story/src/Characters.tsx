import React from 'react';
import {useCurrentFrame} from 'remotion';

export type Who = 'titu' | 'dadu' | 'baba' | 'ma' | 'rahim';
export type Expr = 'happy' | 'laugh' | 'sad' | 'surprised' | 'angry' | 'think' | 'panic' | 'proud' | 'neutral';
const OL = '#222222';
const sw = 2.5;

interface Cfg {skin: string; hrx: number; hry: number; bodyTop: number; bodyH: number; bodyW: number; legLen: number; legW: number; gap: number; armLen: number; armW: number; top: string; sleeve: number; bottom: string; shoe: string;}
const CFG: Record<Who, Cfg> = {
  titu: {skin: '#F5B98A', hrx: 66, hry: 62, bodyTop: 296, bodyH: 100, bodyW: 104, legLen: 134, legW: 26, gap: 24, armLen: 84, armW: 22, top: '#FFD900', sleeve: 30, bottom: '#1F4FD8', shoe: '#3DBE29'},
  dadu: {skin: '#F2B684', hrx: 54, hry: 58, bodyTop: 212, bodyH: 166, bodyW: 120, legLen: 152, legW: 30, gap: 28, armLen: 110, armW: 26, top: '#FAFAFA', sleeve: 110, bottom: '#FFFFFF', shoe: '#8B5A2B'},
  baba: {skin: '#F8C9A0', hrx: 52, hry: 58, bodyTop: 205, bodyH: 160, bodyW: 112, legLen: 165, legW: 30, gap: 28, armLen: 112, armW: 26, top: '#FFFFFF', sleeve: 70, bottom: '#222222', shoe: '#111111'},
  ma: {skin: '#F8CDA0', hrx: 50, hry: 56, bodyTop: 210, bodyH: 165, bodyW: 104, legLen: 155, legW: 26, gap: 24, armLen: 108, armW: 24, top: '#F77FB5', sleeve: 70, bottom: '#F77FB5', shoe: '#E8C07A'},
  rahim: {skin: '#F0A872', hrx: 56, hry: 58, bodyTop: 214, bodyH: 166, bodyW: 136, legLen: 150, legW: 32, gap: 30, armLen: 112, armW: 30, top: '#3F6FD0', sleeve: 50, bottom: '#4A3F35', shoe: '#7A4A22'},
};

type M = 'closed' | 'grin' | 'frown' | 'flat' | 'o' | 'big' | 'small';
const EX: Record<Expr, {bl: number; br: number; by: number; m: M; es: number; arc?: boolean; tear?: boolean; sweat?: boolean}> = {
  neutral: {bl: 0, br: 0, by: 0, m: 'closed', es: 1},
  happy: {bl: 0, br: 0, by: -3, m: 'grin', es: 1},
  laugh: {bl: -6, br: 6, by: -4, m: 'big', es: 1, arc: true},
  sad: {bl: -16, br: 16, by: 0, m: 'frown', es: 1, tear: true},
  surprised: {bl: 0, br: 0, by: -12, m: 'o', es: 1.25},
  angry: {bl: 16, br: -16, by: 2, m: 'flat', es: 1},
  think: {bl: -6, br: 0, by: -4, m: 'flat', es: 1},
  panic: {bl: -18, br: 18, by: -10, m: 'big', es: 1.3, sweat: true},
  proud: {bl: 0, br: 0, by: -6, m: 'grin', es: 1},
};

export const Brush: React.FC = () => (
  <g>
    <rect x={-5} y={-8} width={10} height={58} rx={5} fill="#29B6F6" stroke={OL} strokeWidth={sw} />
    <rect x={-9} y={44} width={18} height={18} rx={5} fill="#fff" stroke={OL} strokeWidth={sw} />
  </g>
);

const Arm: React.FC<{sx: number; sy: number; len: number; w: number; skin: string; sc: string; sl: number; ang: number; side: 'L' | 'R'; up: boolean; children?: React.ReactNode}> = ({sx, sy, len, w, skin, sc, sl, ang, side, up, children}) => {
  const rot = side === 'L' ? ang : -ang;
  return (
    <g transform={`rotate(${rot} ${sx} ${sy})`}>
      <line x1={sx} y1={sy} x2={sx} y2={sy + len} stroke={OL} strokeWidth={w + 5} strokeLinecap="round" />
      <line x1={sx} y1={sy} x2={sx} y2={sy + len} stroke={skin} strokeWidth={w} strokeLinecap="round" />
      {sl > 0 && (
        <g>
          <line x1={sx} y1={sy - w / 2} x2={sx} y2={sy + sl} stroke={OL} strokeWidth={w + 5} />
          <line x1={sx} y1={sy - w / 2} x2={sx} y2={sy + sl} stroke={sc} strokeWidth={w} />
          <line x1={sx - w / 2 - 2} x2={sx + w / 2 + 2} y1={sy + sl} y2={sy + sl} stroke={OL} strokeWidth={3} />
        </g>
      )}
      <circle cx={sx} cy={sy + len} r={w / 2 + 2} fill={skin} stroke={OL} strokeWidth={sw} />
      <g transform={`translate(${sx} ${sy + len}) rotate(${up ? -rot : 0})`}>{children}</g>
    </g>
  );
};

const Leg: React.FC<{x: number; hip: number; len: number; w: number; skin: string; pant: string; pantLen: number; shoe: string; ang: number}> = ({x, hip, len, w, skin, pant, pantLen, shoe, ang}) => (
  <g transform={`rotate(${ang} ${x} ${hip})`}>
    <line x1={x} y1={hip} x2={x} y2={hip + len} stroke={OL} strokeWidth={w + 5} strokeLinecap="round" />
    <line x1={x} y1={hip} x2={x} y2={hip + len} stroke={skin} strokeWidth={w} strokeLinecap="round" />
    {pantLen > 0 && (
      <g>
        <line x1={x} y1={hip} x2={x} y2={hip + pantLen} stroke={OL} strokeWidth={w + 5} />
        <line x1={x} y1={hip} x2={x} y2={hip + pantLen} stroke={pant} strokeWidth={w} />
        <line x1={x - w / 2 - 2} x2={x + w / 2 + 2} y1={hip + pantLen} y2={hip + pantLen} stroke={OL} strokeWidth={3} />
      </g>
    )}
    <ellipse cx={x + 6} cy={hip + len - 2} rx={w * 0.95} ry={11} fill={shoe} stroke={OL} strokeWidth={sw} />
  </g>
);

const MouthEl: React.FC<{cx: number; my: number; shape: M}> = ({cx, my, shape}) => {
  switch (shape) {
    case 'grin':
      return (
        <g>
          <path d={`M ${cx - 22} ${my - 4} Q ${cx} ${my + 30} ${cx + 22} ${my - 4} Z`} fill="#8E1B2B" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
          <path d={`M ${cx - 19} ${my - 2} L ${cx + 19} ${my - 2} Q ${cx + 16} ${my + 7} ${cx} ${my + 7} Q ${cx - 16} ${my + 7} ${cx - 19} ${my - 2} Z`} fill="#fff" />
        </g>
      );
    case 'big':
      return (
        <g>
          <path d={`M ${cx - 20} ${my - 2} Q ${cx} ${my + 36} ${cx + 20} ${my - 2} Z`} fill="#8E1B2B" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
          <ellipse cx={cx} cy={my + 14} rx={10} ry={6} fill="#F48FB1" />
        </g>
      );
    case 'small':
      return <ellipse cx={cx} cy={my + 4} rx={10} ry={7} fill="#8E1B2B" stroke={OL} strokeWidth={sw} />;
    case 'o':
      return <ellipse cx={cx} cy={my + 6} rx={11} ry={15} fill="#8E1B2B" stroke={OL} strokeWidth={sw} />;
    case 'frown':
      return <path d={`M ${cx - 14} ${my + 8} Q ${cx} ${my - 6} ${cx + 14} ${my + 8}`} fill="none" stroke={OL} strokeWidth={4} strokeLinecap="round" />;
    case 'flat':
      return <path d={`M ${cx - 12} ${my + 4} L ${cx + 12} ${my + 2}`} fill="none" stroke={OL} strokeWidth={4} strokeLinecap="round" />;
    default:
      return <path d={`M ${cx - 16} ${my} Q ${cx} ${my + 12} ${cx + 16} ${my}`} fill="none" stroke={OL} strokeWidth={4} strokeLinecap="round" />;
  }
};

export interface CharProps {
  who: Who; x: number; y?: number; scale?: number; flip?: boolean; expr?: Expr; talk?: boolean;
  armL?: number; armR?: number; handL?: React.ReactNode; handR?: React.ReactNode; upL?: boolean; upR?: boolean;
  walk?: boolean; foam?: number; santa?: boolean; tremble?: boolean; cane?: boolean;
}

export const Char: React.FC<CharProps> = (p) => {
  const {who, x, y = 1010, scale = 1.6, flip = false, expr = 'neutral', talk = false, armL = 8, armR = 8, handL, handR, upL = true, upR = true, walk = false, foam = 0, santa = false, tremble = false, cane = false} = p;
  const fr = useCurrentFrame();
  const c = CFG[who];
  const cx = 150;
  const bt = c.bodyTop;
  const bw = c.bodyW;
  const hip = bt + c.bodyH;
  const hcy = bt - c.hry + 14;
  const sw1 = walk ? Math.sin(fr / 4) * 20 : 0;
  const bob = walk ? -Math.abs(Math.sin(fr / 4)) * 8 : Math.sin(fr / 20) * 4;
  const tr = tremble ? Math.sin(fr * 3.1) * 5 : 0;
  const blink = (fr + who.length * 17) % 105 < 4;
  const E = EX[expr];
  const cyc: M[] = ['big', 'small', 'closed', 'small', 'big', 'small'];
  const mShape: M = talk ? cyc[Math.floor(fr / 3) % 6] : E.m;
  const eo = c.hrx * 0.4;
  const ey = hcy + 4;
  const my = who === 'dadu' ? hcy + 46 : who === 'rahim' ? hcy + 46 : hcy + 31;
  const closed = blink || !!E.arc;
  const angL = armL + (walk && !handL ? -sw1 * 0.9 : 0);
  const angR = armR + (walk && !handR ? sw1 * 0.9 : 0);
  const browCol = who === 'dadu' ? '#EEEEEE' : OL;
  const pantLen = who === 'titu' ? 48 : who === 'dadu' ? 0 : c.legLen - 10;

  const Eye = (ex: number) =>
    closed ? (
      <path d={`M ${ex - 13} ${ey + 2} Q ${ex} ${E.arc ? ey - 12 : ey + 9} ${ex + 13} ${ey + 2}`} fill="none" stroke={OL} strokeWidth={4} strokeLinecap="round" />
    ) : (
      <g>
        <ellipse cx={ex} cy={ey} rx={13 * E.es} ry={16 * E.es} fill="#fff" stroke={OL} strokeWidth={sw} />
        <circle cx={ex} cy={ey + 1} r={7.5 * E.es} fill="#2B1B12" />
        <circle cx={ex + 3} cy={ey - 3} r={2.6} fill="#fff" />
      </g>
    );
  const Brow = (bx: number, rot: number) => (
    <g transform={`translate(${bx} ${hcy - 26 + E.by}) rotate(${rot})`}>
      {who === 'dadu' && <line x1={-16} x2={16} y1={0} y2={0} stroke={OL} strokeWidth={10} strokeLinecap="round" />}
      <line x1={-15} x2={15} y1={0} y2={0} stroke={browCol} strokeWidth={6} strokeLinecap="round" />
    </g>
  );

  const foamDots: React.ReactNode[] = [];
  if (foam > 0) {
    const N = 16;
    const shown = Math.ceil(foam * N);
    for (let i = 0; i < shown; i++) {
      const a = (Math.PI * (0.12 + (0.76 * i) / (N - 1)));
      const fx = cx + (c.hrx - 8) * Math.cos(a) * (i % 2 ? 1 : 0.92);
      const fy = hcy + (c.hry - 6) * Math.sin(a) + (i % 2 ? 6 : 0);
      foamDots.push(<circle key={i} cx={fx} cy={fy} r={15} fill="#fff" stroke={OL} strokeWidth={2} />);
    }
    foamDots.push(<circle key="m1" cx={cx - 16} cy={my - 10} r={12} fill="#fff" stroke={OL} strokeWidth={2} />);
    foamDots.push(<circle key="m2" cx={cx + 16} cy={my - 10} r={12} fill="#fff" stroke={OL} strokeWidth={2} />);
  }

  return (
    <div style={{position: 'absolute', left: x - 150 * scale + tr, top: y - 480 * scale + bob, width: 300 * scale, height: 500 * scale, transform: flip ? 'scaleX(-1)' : undefined}}>
      <svg width={300 * scale} height={500 * scale} viewBox="0 60 300 500" style={{overflow: 'visible'}}>
        <defs>
          <pattern id="chk" width="26" height="26" patternUnits="userSpaceOnUse">
            <rect width="26" height="26" fill="#3F6FD0" />
            <rect width="13" height="13" fill="#fff" opacity=".85" />
            <rect x="13" y="13" width="13" height="13" fill="#fff" opacity=".85" />
          </pattern>
        </defs>
        <ellipse cx={cx} cy={538} rx={80} ry={10} fill="rgba(0,0,0,.18)" />

        {/* legs */}
        <Leg x={cx - c.gap} hip={hip} len={c.legLen} w={c.legW} skin={c.skin} pant={c.bottom} pantLen={pantLen} shoe={c.shoe} ang={sw1} />
        <Leg x={cx + c.gap} hip={hip} len={c.legLen} w={c.legW} skin={c.skin} pant={c.bottom} pantLen={pantLen} shoe={c.shoe} ang={-sw1} />
        {who !== 'dadu' && <rect x={cx - c.gap - c.legW / 2} y={hip - 10} width={2 * c.gap + c.legW} height={34} rx={10} fill={c.bottom} stroke={OL} strokeWidth={sw} />}
        {who === 'dadu' && (
          <g>
            <path d={`M ${cx - bw / 2 + 2} ${hip - 34} L ${cx + bw / 2 - 2} ${hip - 34} L ${cx + 66} ${hip + 122} L ${cx - 66} ${hip + 122} Z`} fill="#fff" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            <line x1={cx - 64} y1={hip + 104} x2={cx + 64} y2={hip + 104} stroke="#90CAF9" strokeWidth={6} />
            <line x1={cx - 65} y1={hip + 116} x2={cx + 65} y2={hip + 116} stroke="#90CAF9" strokeWidth={4} />
          </g>
        )}
        {who === 'ma' && (
          <g>
            <path d={`M ${cx - bw / 2 - 4} ${hip - 30} L ${cx + bw / 2 + 4} ${hip - 30} L ${cx + bw / 2 + 16} ${hip + 74} L ${cx - bw / 2 - 16} ${hip + 74} Z`} fill="#F77FB5" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            <rect x={cx - bw / 2 - 15} y={hip + 58} width={bw + 30} height={14} fill="#FBB4D4" />
            {[[-30, 20], [10, 30], [38, 10], [-8, 50], [-42, 52]].map(([dx, dy], i) => <circle key={i} cx={cx + dx} cy={hip + dy} r={6} fill="#FBB4D4" />)}
          </g>
        )}

        {/* body */}
        {who === 'rahim' ? (
          <rect x={cx - bw / 2} y={bt} width={bw} height={c.bodyH} rx={26} fill="url(#chk)" stroke={OL} strokeWidth={sw} />
        ) : (
          <rect x={cx - bw / 2} y={bt} width={bw} height={c.bodyH} rx={26} fill={c.top} stroke={OL} strokeWidth={sw} />
        )}
        {who === 'titu' && <path d={`M ${cx - 20} ${bt} Q ${cx} ${bt + 16} ${cx + 20} ${bt}`} fill="#FFC400" stroke={OL} strokeWidth={sw} />}
        {who === 'dadu' && (
          <g>
            <line x1={cx} y1={bt + 4} x2={cx} y2={bt + 110} stroke="#B0BEC5" strokeWidth={3} />
            {[34, 64, 94].map((d) => <circle key={d} cx={cx} cy={bt + d} r={5} fill="#fff" stroke="#78909C" strokeWidth={2} />)}
            <rect x={cx - 26} y={bt - 4} width={52} height={14} rx={7} fill="#fff" stroke={OL} strokeWidth={sw} />
          </g>
        )}
        {who === 'baba' && (
          <g>
            <path d={`M ${cx - 24} ${bt - 2} L ${cx - 2} ${bt + 32} L ${cx - 34} ${bt + 26} Z`} fill="#fff" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            <path d={`M ${cx + 24} ${bt - 2} L ${cx + 2} ${bt + 32} L ${cx + 34} ${bt + 26} Z`} fill="#fff" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            <rect x={cx + 14} y={bt + 50} width={22} height={26} rx={3} fill="none" stroke="#B0BEC5" strokeWidth={2.5} />
            <rect x={cx - bw / 2} y={hip - 18} width={bw} height={14} fill="#111" stroke={OL} strokeWidth={sw} />
            <rect x={cx - 9} y={hip - 20} width={18} height={18} rx={3} fill="#CFD8DC" stroke={OL} strokeWidth={sw} />
          </g>
        )}
        {who === 'rahim' && (
          <g>
            {[-34, 8].map((dx, i) => (
              <g key={i}>
                <rect x={cx + dx} y={bt - 4} width={26} height={152} rx={8} fill="#fff" stroke={OL} strokeWidth={sw} />
                {[110, 120, 130].map((d) => <line key={d} x1={cx + dx} x2={cx + dx + 26} y1={bt + d} y2={bt + d} stroke="#E53935" strokeWidth={5} />)}
              </g>
            ))}
          </g>
        )}
        {who === 'ma' && (
          <g>
            <path d={`M ${cx - 18} ${bt} Q ${cx} ${bt + 18} ${cx + 18} ${bt}`} fill="#F9A2C8" stroke={OL} strokeWidth={sw} />
            <path d={`M ${cx - bw / 2 - 8} ${bt + 4} Q ${cx} ${bt + 78} ${cx + bw / 2 + 8} ${bt + 4} L ${cx + bw / 2 + 12} ${bt + 96} Q ${cx} ${bt + 60} ${cx - bw / 2 - 12} ${bt + 96} Z`} fill="#F9A2C8" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            <path d={`M ${cx - 62} ${hcy + 50} Q ${cx - 86} ${hcy + 110} ${cx - 64} ${hcy + 188}`} fill="none" stroke={OL} strokeWidth={29} strokeLinecap="round" />
            <path d={`M ${cx - 62} ${hcy + 50} Q ${cx - 86} ${hcy + 110} ${cx - 64} ${hcy + 188}`} fill="none" stroke="#1A1A1A" strokeWidth={24} strokeLinecap="round" />
            <rect x={cx - 78} y={hcy + 176} width={28} height={10} rx={4} fill="#FF4081" stroke={OL} strokeWidth={2} />
          </g>
        )}
        {who === 'dadu' && cane && (
          <g>
            <line x1={242} y1={324} x2={242} y2={528} stroke={OL} strokeWidth={14} strokeLinecap="round" />
            <line x1={242} y1={324} x2={242} y2={528} stroke="#8D5524" strokeWidth={9} strokeLinecap="round" />
            <path d="M242 326 Q242 300 262 300 Q282 300 282 318" fill="none" stroke={OL} strokeWidth={14} strokeLinecap="round" />
            <path d="M242 326 Q242 300 262 300 Q282 300 282 318" fill="none" stroke="#8D5524" strokeWidth={9} strokeLinecap="round" />
          </g>
        )}

        {/* arms */}
        <Arm sx={cx - (bw / 2 - 6)} sy={bt + 22} len={c.armLen} w={c.armW} skin={c.skin} sc={who === 'rahim' ? '#3F6FD0' : who === 'ma' ? '#F77FB5' : c.top} sl={c.sleeve} ang={angL} side="L" up={upL}>{handL}</Arm>
        <Arm sx={cx + (bw / 2 - 6)} sy={bt + 22} len={c.armLen} w={c.armW} skin={c.skin} sc={who === 'rahim' ? '#3F6FD0' : who === 'ma' ? '#F77FB5' : c.top} sl={c.sleeve} ang={angR} side="R" up={upR}>{handR}</Arm>

        {/* neck + head */}
        <rect x={cx - 16} y={hcy + c.hry - 18} width={32} height={26} fill={c.skin} stroke={OL} strokeWidth={sw} />
        {who === 'ma' && <path d={`M ${cx - c.hrx - 16} ${hcy + 64} Q ${cx - c.hrx - 22} ${hcy - 96} ${cx} ${hcy - 96} Q ${cx + c.hrx + 22} ${hcy - 96} ${cx + c.hrx + 16} ${hcy + 64} Z`} fill="#F9A2C8" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />}
        <circle cx={cx - c.hrx} cy={hcy + 4} r={13} fill={c.skin} stroke={OL} strokeWidth={sw} />
        <circle cx={cx + c.hrx} cy={hcy + 4} r={13} fill={c.skin} stroke={OL} strokeWidth={sw} />
        {who === 'ma' && (<g><circle cx={cx - c.hrx} cy={hcy + 20} r={5} fill="#FFC107" stroke={OL} strokeWidth={1.5} /><circle cx={cx + c.hrx} cy={hcy + 20} r={5} fill="#FFC107" stroke={OL} strokeWidth={1.5} /></g>)}
        <ellipse cx={cx} cy={hcy} rx={c.hrx} ry={c.hry} fill={c.skin} stroke={OL} strokeWidth={sw} />

        {who === 'dadu' && (
          <path d={`M ${cx - c.hrx + 2} ${hcy + 6} Q ${cx - c.hrx - 2} ${hcy + 80} ${cx} ${hcy + 84} Q ${cx + c.hrx + 2} ${hcy + 80} ${cx + c.hrx - 2} ${hcy + 6} Q ${cx + 34} ${hcy + 30} ${cx} ${hcy + 30} Q ${cx - 34} ${hcy + 30} ${cx - c.hrx + 2} ${hcy + 6} Z`} fill="#F7F7F7" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
        )}
        <ellipse cx={cx - c.hrx * 0.58} cy={hcy + 26} rx={11} ry={7} fill="#F48FB1" opacity={0.35} />
        <ellipse cx={cx + c.hrx * 0.58} cy={hcy + 26} rx={11} ry={7} fill="#F48FB1" opacity={0.35} />
        <path d={`M ${cx - 3} ${hcy + 14} Q ${cx + 5} ${hcy + 22} ${cx - 2} ${hcy + 24}`} fill="none" stroke={OL} strokeWidth={2.5} strokeLinecap="round" />
        {Eye(cx - eo)}
        {Eye(cx + eo)}
        {who === 'baba' && (
          <g fill="rgba(255,255,255,.18)" stroke={OL} strokeWidth={4}>
            <rect x={cx - eo - 21} y={ey - 17} width={42} height={34} rx={9} />
            <rect x={cx + eo - 21} y={ey - 17} width={42} height={34} rx={9} />
            <line x1={cx - eo + 21} y1={ey - 6} x2={cx + eo - 21} y2={ey - 6} />
            <line x1={cx - eo - 21} y1={ey - 6} x2={cx - c.hrx - 6} y2={ey - 8} />
            <line x1={cx + eo + 21} y1={ey - 6} x2={cx + c.hrx + 6} y2={ey - 8} />
          </g>
        )}
        {who === 'dadu' && (
          <g fill="rgba(255,255,255,.15)" stroke="#5D4037" strokeWidth={4}>
            <circle cx={cx - eo} cy={ey} r={22} />
            <circle cx={cx + eo} cy={ey} r={22} />
            <line x1={cx - eo + 22} y1={ey - 2} x2={cx + eo - 22} y2={ey - 2} />
          </g>
        )}
        {who === 'dadu' && <path d={`M ${cx - 32} ${hcy + 32} Q ${cx - 14} ${hcy + 16} ${cx} ${hcy + 30} Q ${cx + 14} ${hcy + 16} ${cx + 32} ${hcy + 32} Q ${cx + 14} ${hcy + 38} ${cx} ${hcy + 34} Q ${cx - 14} ${hcy + 38} ${cx - 32} ${hcy + 32} Z`} fill="#F2F2F2" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />}
        {who === 'rahim' && <path d={`M ${cx - 38} ${hcy + 30} Q ${cx - 18} ${hcy + 14} ${cx} ${hcy + 28} Q ${cx + 18} ${hcy + 14} ${cx + 38} ${hcy + 30} Q ${cx + 18} ${hcy + 42} ${cx} ${hcy + 32} Q ${cx - 18} ${hcy + 42} ${cx - 38} ${hcy + 30} Z`} fill="#1A1A1A" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />}
        <MouthEl cx={cx} my={my} shape={mShape} />

        {/* hair & headwear */}
        {who === 'titu' && (
          <g fill="#111" stroke={OL} strokeWidth={sw} strokeLinejoin="round">
            {[[-55, -38, 28], [-30, -62, 30], [0, -70, 32], [32, -62, 30], [58, -36, 28], [-66, -8, 16], [66, -8, 16]].map(([dx, dy, r], i) => <circle key={i} cx={cx + dx} cy={hcy + dy} r={r} />)}
            <polygon points={`${cx - 60},${hcy - 30} ${cx - 44},${hcy - 26} ${cx - 30},${hcy - 44} ${cx - 14},${hcy - 26} ${cx},${hcy - 46} ${cx + 14},${hcy - 26} ${cx + 30},${hcy - 44} ${cx + 44},${hcy - 26} ${cx + 60},${hcy - 30} ${cx + 62},${hcy - 64} ${cx - 62},${hcy - 64}`} />
          </g>
        )}
        {who === 'baba' && <path d={`M ${cx - 52} ${hcy - 8} Q ${cx - 56} ${hcy - 62} ${cx - 4} ${hcy - 64} Q ${cx + 54} ${hcy - 62} ${cx + 52} ${hcy - 8} Q ${cx + 44} ${hcy - 34} ${cx + 20} ${hcy - 34} Q ${cx - 10} ${hcy - 24} ${cx - 52} ${hcy - 8} Z`} fill="#111" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />}
        {who === 'dadu' && (
          <g fill="#F2F2F2" stroke={OL} strokeWidth={sw} strokeLinejoin="round">
            <path d={`M ${cx - 52} ${hcy - 14} Q ${cx - 50} ${hcy - 62} ${cx} ${hcy - 62} Q ${cx + 50} ${hcy - 62} ${cx + 52} ${hcy - 14} Q ${cx + 30} ${hcy - 38} ${cx} ${hcy - 36} Q ${cx - 30} ${hcy - 38} ${cx - 52} ${hcy - 14} Z`} />
            <circle cx={cx - c.hrx + 2} cy={hcy - 4} r={13} /><circle cx={cx + c.hrx - 2} cy={hcy - 4} r={13} />
          </g>
        )}
        {who === 'ma' && (
          <g>
            <path d={`M ${cx - 50} ${hcy - 10} Q ${cx - 48} ${hcy - 52} ${cx} ${hcy - 54} Q ${cx + 48} ${hcy - 52} ${cx + 50} ${hcy - 10} Q ${cx + 26} ${hcy - 40} ${cx} ${hcy - 38} Q ${cx - 26} ${hcy - 40} ${cx - 50} ${hcy - 10} Z`} fill="#1A1A1A" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            <path d={`M ${cx - 58} ${hcy - 30} Q ${cx - 64} ${hcy + 10} ${cx - 62} ${hcy + 62} L ${cx - 46} ${hcy + 60} Q ${cx - 50} ${hcy + 6} ${cx - 42} ${hcy - 34} Z`} fill="#F9A2C8" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            <path d={`M ${cx + 58} ${hcy - 30} Q ${cx + 64} ${hcy + 10} ${cx + 62} ${hcy + 62} L ${cx + 46} ${hcy + 60} Q ${cx + 50} ${hcy + 6} ${cx + 42} ${hcy - 34} Z`} fill="#F9A2C8" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            <circle cx={cx} cy={hcy - 30} r={4.5} fill="#C62828" />
          </g>
        )}
        {who === 'rahim' && (
          <g>
            <path d={`M ${cx - 52} ${hcy - 20} Q ${cx - 50} ${hcy - 40} ${cx - 40} ${hcy - 40} L ${cx + 40} ${hcy - 40} Q ${cx + 50} ${hcy - 40} ${cx + 52} ${hcy - 20} Z`} fill="#111" stroke={OL} strokeWidth={sw} />
            <path d={`M ${cx - 46} ${hcy - 28} Q ${cx} ${hcy - 84} ${cx + 46} ${hcy - 28} L ${cx + 48} ${hcy - 20} L ${cx - 48} ${hcy - 20} Z`} fill="#fff" stroke={OL} strokeWidth={sw} strokeLinejoin="round" />
            {[-26, -8, 10, 28].map((dx, i) => <circle key={i} cx={cx + dx} cy={hcy - 38 - (i % 2) * 8} r={4} fill="#CFD8DC" />)}
          </g>
        )}
        {santa && (
          <g stroke={OL} strokeWidth={sw} strokeLinejoin="round">
            <path d={`M ${cx - 60} ${hcy - 34} L ${cx + 62} ${hcy - 34} Q ${cx + 64} ${hcy - 100} ${cx + 40} ${hcy - 100} Q ${cx - 30} ${hcy - 110} ${cx - 60} ${hcy - 34} Z`} fill="#E53935" />
            <rect x={cx - 68} y={hcy - 46} width={136} height={22} rx={11} fill="#fff" />
            <circle cx={cx + 44} cy={hcy - 102} r={15} fill="#fff" />
          </g>
        )}
        {foamDots}
        {Brow(cx - eo, E.bl)}
        {Brow(cx + eo, E.br)}
        {E.tear && [-1, 1].map((sd) => <ellipse key={sd} cx={cx + sd * (eo + 4)} cy={ey + 28 + ((fr % 30) * 0.7)} rx={5} ry={8} fill="#4FC3F7" stroke={OL} strokeWidth={1.5} />)}
        {E.sweat && <path d={`M ${cx + c.hrx - 8} ${hcy - c.hry + 22} q 8 14 0 20 q -8 -6 0 -20 Z`} fill="#81D4FA" stroke={OL} strokeWidth={2} />}
      </svg>
    </div>
  );
};
