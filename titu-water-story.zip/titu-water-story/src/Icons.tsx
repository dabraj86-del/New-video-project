import React from 'react';

const OL = '#222222';
const S = {stroke: OL, strokeWidth: 4, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

export const Ico: React.FC<{size: number; children: React.ReactNode; style?: React.CSSProperties}> = ({size, children, style}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible', ...style}}>{children}</svg>
);
// ক্যারেক্টারের হাতে ধরার জন্য (নেস্টেড SVG)
export const HandIco: React.FC<{size: number; dx?: number; dy?: number; children: React.ReactNode}> = ({size, dx = 0, dy = 0, children}) => (
  <svg x={-size / 2 + dx} y={dy} width={size} height={size} viewBox="0 0 100 100" overflow="visible">{children}</svg>
);

export const Drop = () => (
  <g>
    <path d="M50 8 C50 8 20 46 20 64 a30 30 0 0 0 60 0 C80 46 50 8 50 8Z" fill="#4FC3F7" {...S} />
    <path d="M36 62 a14 14 0 0 0 10 14" stroke="#fff" strokeWidth={5} fill="none" strokeLinecap="round" />
  </g>
);
export const Note = () => (
  <g>
    <ellipse cx="34" cy="76" rx="17" ry="12" fill="#E91E63" {...S} />
    <path d="M50 74 V16 Q80 22 78 48" fill="none" {...S} strokeWidth={7} />
  </g>
);
export const Boat = () => (
  <g>
    <path d="M50 10 V58" fill="none" {...S} />
    <path d="M54 14 L86 52 H54Z" fill="#FFD600" {...S} />
    <path d="M8 58 H92 L76 84 H24Z" fill="#E53935" {...S} />
  </g>
);
export const Tank: React.FC<{level?: number}> = ({level = 1}) => {
  const h = 56 * level;
  return (
    <g>
      <rect x="38" y="8" width="24" height="14" rx="3" fill="#90A4AE" {...S} />
      <rect x="24" y="22" width="52" height="62" rx="10" fill="#ECEFF1" {...S} />
      <rect x="28" y={80 - h} width="44" height={h} rx="4" fill="#4FC3F7" />
      <rect x="24" y="22" width="52" height="62" rx="10" fill="none" {...S} />
    </g>
  );
};
export const Bulb = () => (
  <g>
    <path d="M50 12 a26 26 0 0 1 14 48 v10 h-28 v-10 a26 26 0 0 1 14 -48Z" fill="#FFEB3B" {...S} />
    <rect x="38" y="70" width="24" height="14" rx="4" fill="#90A4AE" {...S} />
    <path d="M50 0 V-10 M14 16 L6 8 M86 16 L94 8" fill="none" {...S} />
  </g>
);
export const Coin = () => (
  <g>
    <circle cx="50" cy="50" r="36" fill="#FFC107" {...S} />
    <circle cx="50" cy="50" r="26" fill="none" stroke="#B8860B" strokeWidth="3" />
    <text x="50" y="62" textAnchor="middle" fontSize="36" fontWeight="700" fill="#8A5A00" fontFamily="Hind Siliguri, sans-serif">৳</text>
  </g>
);
export const Bank: React.FC<{broken?: boolean}> = ({broken}) =>
  broken ? (
    <g>
      <path d="M14 54 Q14 26 40 26 L50 40 L44 52 L52 66 L46 84 Q22 82 14 54Z" fill="#C97B4A" {...S} />
      <path d="M62 40 L70 26 Q94 30 92 56 Q90 80 62 84 L56 66 L62 52Z" fill="#C97B4A" {...S} />
    </g>
  ) : (
    <g>
      <rect x="30" y="82" width="12" height="10" rx="3" fill="#8D5524" {...S} />
      <rect x="58" y="82" width="12" height="10" rx="3" fill="#8D5524" {...S} />
      <ellipse cx="50" cy="58" rx="36" ry="30" fill="#C97B4A" {...S} />
      <rect x="32" y="24" width="36" height="10" rx="5" fill="#8D5524" {...S} />
      <rect x="40" y="28" width="20" height="3" rx="1.5" fill="#222" />
    </g>
  );
export const Bucket: React.FC<{level?: number; hole?: boolean}> = ({level = 0, hole}) => {
  const h = 46 * level;
  return (
    <g>
      <path d="M24 38 Q50 -6 76 38" fill="none" {...S} />
      <clipPath id="bkc"><path d="M20 36 H80 L72 88 H28Z" /></clipPath>
      <path d="M20 36 H80 L72 88 H28Z" fill="#CFD8DC" {...S} />
      <g clipPath="url(#bkc)"><rect x="10" y={88 - h} width="80" height={h} fill="#4FC3F7" /></g>
      <path d="M20 36 H80 L72 88 H28Z" fill="none" {...S} />
      <ellipse cx="50" cy="36" rx="30" ry="6" fill="#B0BEC5" {...S} />
      {hole && <circle cx="50" cy="85" r="5" fill="#222" />}
    </g>
  );
};
export const Mug: React.FC<{level?: number}> = ({level = 0}) => {
  const h = 48 * level;
  return (
    <g>
      <path d="M72 38 Q96 40 92 56 Q88 68 72 68" fill="none" {...S} />
      <clipPath id="mugc"><rect x="26" y="24" width="46" height="58" rx="8" /></clipPath>
      <rect x="26" y="24" width="46" height="58" rx="8" fill="#B0BEC5" {...S} />
      <g clipPath="url(#mugc)"><rect x="26" y={82 - h} width="46" height={h} fill="#4FC3F7" /></g>
      <rect x="26" y="24" width="46" height="58" rx="8" fill="none" {...S} />
    </g>
  );
};
export const TeaCup = () => (
  <g>
    <path d="M36 32 Q30 22 38 14 M52 32 Q46 22 54 12" fill="none" stroke="#B0BEC5" strokeWidth="4" strokeLinecap="round" />
    <path d="M70 46 Q92 46 88 60 Q84 72 68 70" fill="none" {...S} />
    <path d="M22 40 H70 V60 Q70 82 46 82 Q22 82 22 60Z" fill="#FFFFFF" {...S} />
    <rect x="24" y="42" width="44" height="7" fill="#8D5524" opacity=".7" />
  </g>
);
export const Check = () => (
  <g>
    <circle cx="50" cy="50" r="38" fill="#2E7D32" {...S} />
    <path d="M30 52 L45 66 L72 36" stroke="#fff" strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </g>
);
export const Cross = () => (
  <g>
    <circle cx="50" cy="50" r="38" fill="#C62828" {...S} />
    <path d="M34 34 L66 66 M66 34 L34 66" stroke="#fff" strokeWidth={9} fill="none" strokeLinecap="round" />
  </g>
);
export const Egg = () => (
  <g>
    <ellipse cx="50" cy="56" rx="26" ry="34" fill="#FFD54F" {...S} />
    <path d="M36 46 Q38 34 48 30" stroke="#fff" strokeWidth={5} fill="none" strokeLinecap="round" />
  </g>
);
export const Bottle: React.FC<{level?: number}> = ({level = 1}) => {
  const h = 54 * level;
  return (
    <g>
      <clipPath id="btc"><path d="M36 28 H64 V86 Q64 92 58 92 H42 Q36 92 36 86Z" /></clipPath>
      <path d="M36 28 H64 V86 Q64 92 58 92 H42 Q36 92 36 86Z" fill="#E1F5FE" {...S} />
      <g clipPath="url(#btc)"><rect x="30" y={90 - h} width="40" height={h} fill="#4FC3F7" /></g>
      <path d="M36 28 H64 V86 Q64 92 58 92 H42 Q36 92 36 86Z" fill="none" {...S} />
      <rect x="40" y="10" width="20" height="18" rx="4" fill="#fff" {...S} />
    </g>
  );
};
export const Tooth = () => (
  <g>
    <path d="M26 30 Q26 14 44 20 Q50 22 56 20 Q74 14 74 30 Q74 52 66 62 Q64 88 54 88 Q50 88 50 70 Q50 88 46 88 Q36 88 34 62 Q26 52 26 30Z" fill="#fff" {...S} />
  </g>
);
export const Foam = () => (
  <g fill="#fff" {...S} strokeWidth={3}>
    <circle cx="32" cy="58" r="18" /><circle cx="58" cy="50" r="22" /><circle cx="76" cy="66" r="14" /><circle cx="50" cy="74" r="16" /><circle cx="44" cy="34" r="12" />
  </g>
);
export const Question = () => (
  <g>
    <circle cx="50" cy="50" r="38" fill="#FFB300" {...S} />
    <text x="50" y="68" textAnchor="middle" fontSize="56" fontWeight="700" fill="#222" fontFamily="Hind Siliguri, sans-serif">?</text>
  </g>
);
