import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {FONT} from './font';
import {CHUNKS, Co, FPS, KEYS, SUP, f} from './data';
import {Ico} from './Icons';

export const SceneCtx = createContext(0);
export const Scene: React.FC<{from: number; to: number; children: React.ReactNode}> = ({from, to, children}) => (
  <Sequence from={f(from)} durationInFrames={f(to) - f(from)}>
    <SceneCtx.Provider value={from}>
      <AbsoluteFill>{children}</AbsoluteFill>
    </SceneCtx.Provider>
  </Sequence>
);
export const useT = () => {
  const fr = useCurrentFrame();
  const s = useContext(SceneCtx);
  return s + fr / FPS;
};
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const ez = (t: number, s: number, d = 0.5) => clamp((t - s) / d);
export const back = (x: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};
export const kf = (t: number, pts: [number, number][]) => {
  if (t <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    if (t <= pts[i][0]) {
      const [t0, v0] = pts[i - 1];
      const [t1, v1] = pts[i];
      return v0 + (v1 - v0) * ((t - t0) / (t1 - t0));
    }
  }
  return pts[pts.length - 1][1];
};

export const Bubble: React.FC<{co: Co; x: number; y: number; w?: number; tail?: number; color?: string; fs?: number}> = ({co, x, y, w = 640, tail = 0.5, color = '#1E4FD8', fs = 50}) => {
  const t = useT();
  if (t < co.s || t > co.e + 0.3) return null;
  const p = back(ez(t, co.s, 0.35));
  const o = 1 - ez(t, co.e, 0.25);
  return (
    <div style={{position: 'absolute', left: x - tail * w, top: y, width: w, transform: `translate(0,calc(-100% - 26px)) scale(${p})`, transformOrigin: `${tail * 100}% 100%`, opacity: o, fontFamily: FONT}}>
      <div style={{background: '#fff', border: '5px solid #222', borderRadius: 36, padding: '14px 28px 18px', boxShadow: '0 8px 0 rgba(0,0,0,.18)'}}>
        <div style={{fontSize: 30, fontWeight: 700, color}}>{co.who}</div>
        <div style={{fontSize: fs, fontWeight: 700, color: '#222', lineHeight: 1.3}}>{co.text}</div>
      </div>
      <div style={{position: 'absolute', left: `${tail * 100}%`, bottom: -22, width: 36, height: 36, background: '#fff', borderRight: '5px solid #222', borderBottom: '5px solid #222', transform: 'translateX(-50%) rotate(45deg)'}} />
    </div>
  );
};

export const Thought: React.FC<{s: number; e: number; x: number; y: number; w?: number; h?: number; children: React.ReactNode}> = ({s, e, x, y, w = 360, h = 220, children}) => {
  const t = useT();
  if (t < s || t > e + 0.3) return null;
  const p = back(ez(t, s, 0.4));
  const o = 1 - ez(t, e, 0.3);
  const dot = (l: number, tp: number, sz: number) => (
    <div style={{position: 'absolute', left: l, top: tp, width: sz, height: sz, borderRadius: '50%', background: '#fff', border: '5px solid #222'}} />
  );
  return (
    <div style={{position: 'absolute', left: x - w / 2, top: y - h - 90, width: w, height: h + 90, opacity: o, transform: `scale(${p})`, transformOrigin: '50% 100%'}}>
      <div style={{width: w, height: h, background: '#fff', border: '5px solid #222', borderRadius: h / 2, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, boxShadow: '0 8px 0 rgba(0,0,0,.18)'}}>{children}</div>
      {dot(w / 2 - 12, h + 8, 36)}
      {dot(w / 2 - 28, h + 54, 22)}
    </div>
  );
};

export const StampB: React.FC<{st: Co; x: number; y: number; color?: string; rot?: number; icon?: React.ReactNode}> = ({st, x, y, color = '#D32F2F', rot = -6, icon}) => {
  const t = useT();
  if (t < st.s || t > st.e + 0.3) return null;
  const p = back(ez(t, st.s, 0.35));
  const o = 1 - ez(t, st.e, 0.3);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${p})`, opacity: o, border: `9px solid ${color}`, color, background: 'rgba(255,255,255,.93)', borderRadius: 22, padding: '8px 38px', fontFamily: FONT, fontWeight: 700, fontSize: 86, whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: 20, boxShadow: '0 8px 0 rgba(0,0,0,.2)'}}>
      {icon}
      {st.text}
    </div>
  );
};

export const Badge: React.FC<{s: number; x: number; y: number; name: string; sub: string; color: string}> = ({s, x, y, name, sub, color}) => {
  const t = useT();
  const e = s + 3.2;
  if (t < s || t > e + 0.3) return null;
  const p = back(ez(t, s, 0.4));
  const o = 1 - ez(t, e, 0.3);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${p})`, opacity: o, background: color, color: '#fff', border: '4px solid #222', borderRadius: 999, padding: '8px 30px', fontFamily: FONT, fontWeight: 700, fontSize: 44, whiteSpace: 'nowrap', boxShadow: '0 6px 0 rgba(0,0,0,.2)'}}>
      {name}
      <span style={{fontSize: 30, fontWeight: 500, marginLeft: 14}}>{sub}</span>
    </div>
  );
};

export const LocPill: React.FC<{s: number; text: string}> = ({s, text}) => {
  const t = useT();
  const e = s + 3.6;
  if (t < s || t > e + 0.4) return null;
  const slide = (1 - back(ez(t, s, 0.5))) * -420;
  const o = 1 - ez(t, e, 0.4);
  return (
    <div style={{position: 'absolute', left: 44, top: 40, transform: `translateX(${slide}px)`, opacity: o, background: 'rgba(20,24,40,.82)', color: '#fff', borderRadius: 999, padding: '10px 34px', fontFamily: FONT, fontWeight: 700, fontSize: 38}}>
      {text}
    </div>
  );
};

export const Pop: React.FC<{s: number; e?: number; x: number; y: number; size?: number; anim?: 'none' | 'float' | 'pulse' | 'rise' | 'fall'; children: React.ReactNode}> = ({s, e = 9999, x, y, size = 140, anim = 'float', children}) => {
  const t = useT();
  if (t < s || t > e + 0.3) return null;
  const p = back(ez(t, s, 0.4));
  const out = 1 - ez(t, e, 0.3);
  let dy = 0;
  let sc = 1;
  let op = out;
  if (anim === 'float') dy = Math.sin((t - s) * 3) * 10;
  if (anim === 'pulse') sc = 1 + Math.sin((t - s) * 7) * 0.06;
  if (anim === 'rise') {
    dy = -ez(t, s, 2.4) * 170;
    op = out * (1 - ez(t, s + 1.6, 0.8));
  }
  if (anim === 'fall') {
    dy = ez(t, s, 1.1) * 150;
    op = out * (1 - ez(t, s + 0.5, 0.7));
  }
  return (
    <div style={{position: 'absolute', left: x - size / 2, top: y - size / 2 + dy, width: size, height: size, transform: `scale(${p * sc})`, opacity: op}}>
      <Ico size={size}>{children}</Ico>
    </div>
  );
};

export const Wipe: React.FC<{at: number}> = ({at}) => {
  const t = useT();
  const x = (t - at + 0.35) / 0.7;
  if (x < 0 || x > 1) return null;
  return <AbsoluteFill style={{background: '#fff', opacity: 1 - Math.abs(x * 2 - 1)}} />;
};

export const Cam: React.FC<{shake?: [number, number, number][]; zoom?: {s: number; e: number; k: number; ox: number; oy: number}[]; children: React.ReactNode}> = ({shake = [], zoom = [], children}) => {
  const t = useT();
  const fr = useCurrentFrame();
  let dx = 0;
  let dy = 0;
  let on = false;
  for (const [a, b, amp] of shake) {
    if (t >= a && t <= b) {
      on = true;
      dx += Math.sin(fr * 2.7) * amp;
      dy += Math.cos(fr * 3.3) * amp * 0.7;
    }
  }
  let sc = 1;
  let ox = 960;
  let oy = 540;
  for (const z of zoom) {
    const p = ez(t, z.s, 0.8) * (1 - ez(t, z.e, 0.6));
    if (p > 0) {
      sc = 1 + (z.k - 1) * p;
      ox = z.ox;
      oy = z.oy;
    }
  }
  return (
    <AbsoluteFill style={{transform: `translate(${dx}px,${dy}px) scale(${sc * (on ? 1.03 : 1)})`, transformOrigin: `${ox}px ${oy}px`}}>{children}</AbsoluteFill>
  );
};

const hl = (w: string) => KEYS.some((k) => w.replace(/[,।?!]/g, '').startsWith(k));
export const Caption: React.FC = () => {
  const fr = useCurrentFrame();
  const t = fr / FPS;
  if (SUP.some(([a, b]) => t >= a - 0.05 && t <= b + 0.3)) return null;
  const c = CHUNKS.find((c) => t >= c.s && t < c.e);
  if (!c) return null;
  const p = ez(t, c.s, 0.2);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 52, display: 'flex', justifyContent: 'center', opacity: p, transform: `translateY(${(1 - p) * 26}px)`}}>
      <div style={{background: 'rgba(20,20,30,.66)', padding: '10px 38px 14px', borderRadius: 30, fontFamily: FONT, fontSize: 68, fontWeight: 700, color: '#fff', whiteSpace: 'nowrap', textShadow: '0 3px 0 rgba(0,0,0,.4)'}}>
        {c.text.split(' ').map((w, i) => (
          <span key={i} style={{color: hl(w) ? '#FFD23F' : '#fff'}}>{w}{' '}</span>
        ))}
      </div>
    </div>
  );
};
