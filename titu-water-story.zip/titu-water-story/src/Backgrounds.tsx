import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Mug} from './Icons';

const OL = '#222222';
const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill>
    <svg width="100%" height="100%" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice">{children}</svg>
  </AbsoluteFill>
);

export const Bathroom: React.FC<{door?: boolean; tapOn?: boolean; air?: number; water?: number; mug?: boolean}> = ({door = true, tapOn = false, air = 0, water = 0, mug = false}) => {
  const fr = useCurrentFrame();
  return (
    <Svg>
      <rect width="1920" height="1080" fill="#CFEFF3" />
      {Array.from({length: 17}).map((_, i) => <line key={'v' + i} x1={i * 120} y1={0} x2={i * 120} y2={800} stroke="#B4DDE4" strokeWidth={3} />)}
      {Array.from({length: 7}).map((_, j) => <line key={'h' + j} x1={0} y1={j * 120 + 40} x2={1920} y2={j * 120 + 40} stroke="#B4DDE4" strokeWidth={3} />)}
      <rect y="800" width="1920" height="280" fill="#8FB4C4" />
      {Array.from({length: 12}).map((_, i) => <line key={'f' + i} x1={i * 180} y1={800} x2={i * 260 - 300} y2={1080} stroke="#7AA1B2" strokeWidth={3} />)}
      <rect y="790" width="1920" height="18" fill="#6E96A8" />
      {door && (
        <g stroke={OL} strokeWidth={5}>
          <rect x="40" y="250" width="290" height="560" fill="#B9794B" />
          <rect x="72" y="290" width="226" height="210" fill="none" stroke="#8E5A33" />
          <rect x="72" y="530" width="226" height="240" fill="none" stroke="#8E5A33" />
          <circle cx="290" cy="540" r="14" fill="#FFD54F" />
        </g>
      )}
      <rect x="980" y="120" width="500" height="400" rx="24" fill="#E9F8FF" stroke={OL} strokeWidth={6} />
      <rect x="996" y="136" width="468" height="368" rx="14" fill="none" stroke="#9FD3E6" strokeWidth={8} />
      <path d="M1040 470 L1170 190" stroke="#fff" strokeWidth={16} opacity={0.6} strokeLinecap="round" />
      <path d="M1100 480 L1190 290" stroke="#fff" strokeWidth={9} opacity={0.6} strokeLinecap="round" />
      <rect x="940" y="650" width="720" height="40" rx="8" fill="#fff" stroke={OL} strokeWidth={5} />
      <rect x="970" y="690" width="660" height="112" fill="#E3C9A5" stroke={OL} strokeWidth={5} />
      <line x1="1300" y1="690" x2="1300" y2="802" stroke={OL} strokeWidth={4} />
      <circle cx="1280" cy="746" r="8" fill="#8D5524" /><circle cx="1320" cy="746" r="8" fill="#8D5524" />
      <ellipse cx="1300" cy="654" rx="190" ry="24" fill="#F4FBFF" stroke={OL} strokeWidth={5} />
      <ellipse cx="1300" cy="658" rx="150" ry="14" fill="#DCEFF8" />
      <g stroke={OL} strokeWidth={4}>
        <rect x="1288" y="556" width="24" height="60" fill="#B0BEC5" />
        <rect x="1290" y="552" width="86" height="28" rx="14" fill="#B0BEC5" />
        <rect x="1352" y="572" width="24" height="26" rx="6" fill="#90A4AE" />
        <rect x="1290" y="516" width="22" height="38" rx="6" fill="#90A4AE" />
        <rect x="1270" y="504" width="62" height="18" rx="9" fill="#E53935" />
      </g>
      {tapOn && (
        <g>
          <line x1="1364" y1="600" x2="1364" y2="656" stroke="#6EC6FF" strokeWidth={16} strokeDasharray="18 10" strokeDashoffset={-fr * 9} />
          <ellipse cx="1364" cy="660" rx="28" ry="8" fill="#9BD8FF" />
        </g>
      )}
      {air > 0 && [0, 1, 2].map((i) => <circle key={i} cx={1364 + i * 22 * air} cy={604 + i * 26 * air} r={10 + air * 20} fill="#CFD8DC" opacity={(1 - air) * 0.85} stroke={OL} strokeWidth={2} />)}
      {water > 0 && <ellipse cx="900" cy="950" rx={water * 1000} ry={water * 120} fill="#69B8F0" opacity={0.65} stroke="#2E86C8" strokeWidth={4} />}
      {mug && (
        <g>
          <path d="M440 330 v22" stroke={OL} strokeWidth={5} />
          <svg x="390" y="340" width="100" height="100" viewBox="0 0 100 100"><Mug level={0} /></svg>
        </g>
      )}
    </Svg>
  );
};

export const LivingRoom: React.FC = () => (
  <Svg>
    <rect width="1920" height="1080" fill="#FBE7C0" />
    <rect y="600" width="1920" height="200" fill="#F0CF98" />
    <rect y="596" width="1920" height="10" fill="#D9B070" />
    <rect y="800" width="1920" height="280" fill="#C58F5A" />
    {Array.from({length: 8}).map((_, i) => <line key={i} x1={0} y1={820 + i * 36} x2={1920} y2={820 + i * 36} stroke="#A9743F" strokeWidth={3} />)}
    <g stroke={OL} strokeWidth={6}>
      <rect x="180" y="140" width="420" height="380" fill="#BEE6FF" />
      <line x1="390" y1="140" x2="390" y2="520" /><line x1="180" y1="330" x2="600" y2="330" />
      <path d="M160 130 Q240 300 160 540 L230 540 Q300 300 230 130Z" fill="#E57373" strokeWidth={4} />
      <path d="M620 130 Q540 300 620 540 L550 540 Q480 300 550 130Z" fill="#E57373" strokeWidth={4} />
      <rect x="900" y="150" width="240" height="170" fill="#C8E6C9" />
      <rect x="918" y="168" width="204" height="134" fill="#A5D6A7" strokeWidth={3} />
    </g>
    <g stroke={OL} strokeWidth={6}>
      <rect x="900" y="470" width="780" height="300" rx="44" fill="#2E8B8B" />
      <rect x="950" y="500" width="320" height="170" rx="30" fill="#3AA6A6" strokeWidth={4} />
      <rect x="1310" y="500" width="320" height="170" rx="30" fill="#3AA6A6" strokeWidth={4} />
    </g>
  </Svg>
);

export const SofaFront: React.FC = () => (
  <Svg>
    <g stroke={OL} strokeWidth={6}>
      <rect x="880" y="690" width="820" height="150" rx="32" fill="#3AA6A6" />
      <rect x="850" y="560" width="100" height="290" rx="38" fill="#2E8B8B" />
      <rect x="1630" y="560" width="100" height="290" rx="38" fill="#2E8B8B" />
      <rect x="900" y="840" width="40" height="30" rx="8" fill="#6D4C2F" /><rect x="1640" y="840" width="40" height="30" rx="8" fill="#6D4C2F" />
    </g>
  </Svg>
);

export const Yard: React.FC<{scroll?: number; tapPost?: boolean}> = ({scroll = 0, tapPost = false}) => {
  const P = 1920;
  const off = ((scroll % P) + P) % P;
  const unit = (o: number, k: number) => (
    <g key={k} transform={`translate(${o} 0)`} stroke={OL} strokeWidth={4} strokeLinejoin="round">
      <polygon points="150,450 260,360 560,360 670,450" fill="#8D9BA5" />
      <rect x="190" y="450" width="440" height="330" fill="#D3D8DC" />
      <rect x="250" y="520" width="120" height="110" fill="#6D4C2F" />
      <line x1="310" y1="520" x2="310" y2="630" /><line x1="250" y1="575" x2="370" y2="575" />
      <rect x="470" y="560" width="100" height="220" fill="#8D6E63" />
      <ellipse cx="800" cy="780" rx="110" ry="60" fill="#43A047" />
      <rect x="1090" y="430" width="56" height="360" fill="#A0693B" />
      <circle cx="1020" cy="440" r="100" fill="#4CAF50" /><circle cx="1220" cy="440" r="100" fill="#4CAF50" />
      <circle cx="1118" cy="370" r="140" fill="#5CBF60" /><circle cx="1118" cy="290" r="100" fill="#66BB6A" />
      <rect x="1390" y="660" width="470" height="18" fill="#E0B56A" /><rect x="1390" y="730" width="470" height="18" fill="#E0B56A" />
      {Array.from({length: 6}).map((_, i) => <rect key={i} x={1400 + i * 88} y={620} width={22} height={170} fill="#E0B56A" />)}
    </g>
  );
  return (
    <Svg>
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7FCBFF" /><stop offset="1" stopColor="#D6F1FF" /></linearGradient>
      </defs>
      <rect width="1920" height="1080" fill="url(#sky)" />
      <ellipse cx="400" cy="180" rx="120" ry="44" fill="#fff" /><ellipse cx="470" cy="160" rx="90" ry="40" fill="#fff" />
      <ellipse cx="1400" cy="130" rx="130" ry="46" fill="#fff" />
      <rect y="760" width="1920" height="320" fill="#7ACB52" />
      <rect y="900" width="1920" height="180" fill="#E9C58C" />
      {[-1, 0, 1].map((k) => unit(-off + k * P, k))}
      {tapPost && (
        <g stroke={OL} strokeWidth={4}>
          <rect x="1388" y="560" width="26" height="250" fill="#78909C" />
          <rect x="1360" y="800" width="82" height="24" rx="6" fill="#90A4AE" />
          <rect x="1330" y="552" width="86" height="28" rx="14" fill="#90A4AE" />
          <rect x="1330" y="574" width="22" height="24" rx="6" fill="#78909C" />
          <rect x="1376" y="528" width="50" height="16" rx="8" fill="#E53935" />
        </g>
      )}
    </Svg>
  );
};

const PK = ['#E53935', '#1E88E5', '#43A047', '#FDD835', '#FB8C00', '#8E24AA'];
export const Shop: React.FC = () => (
  <Svg>
    <rect width="1920" height="1080" fill="#BDE7FF" />
    <rect y="900" width="1920" height="180" fill="#E2C28F" />
    <path d="M1500 900 L1920 850 V1080 H1500Z" fill="#9E9E9E" stroke={OL} strokeWidth={4} />
    <path d="M1560 1000 Q1740 960 1920 940" stroke="#fff" strokeWidth={8} fill="none" strokeDasharray="40 24" />
    <g stroke={OL} strokeWidth={4}>
      <rect x="1700" y="420" width="46" height="400" fill="#A0693B" />
      <circle cx="1723" cy="380" r="130" fill="#4CAF50" /><circle cx="1640" cy="450" r="80" fill="#5CBF60" />
      <rect x="0" y="120" width="1500" height="780" fill="#C99A5B" />
      {[0, 1].map((r) => <rect key={r} x={0} y={300 + r * 190} width={1500} height={16} fill="#8D5C2E" />)}
      {[0, 1].map((r) => Array.from({length: 12}).map((_, i) => <rect key={r + '-' + i} x={50 + i * 120} y={180 + r * 190} width={84} height={120} rx={8} fill={PK[(i + r * 2) % 6]} />))}
      {Array.from({length: 14}).map((_, i) => <rect key={i} x={i * 108} y={40} width={108} height={120} fill={i % 2 ? '#fff' : '#E53935'} />)}
      <rect x="0" y="150" width="1500" height="16" fill="#8D5C2E" />
    </g>
  </Svg>
);
export const ShopCounter: React.FC = () => {
  const jar = (x: number, c: string) => (
    <g key={x} stroke={OL} strokeWidth={4}>
      <rect x={x} y={684} width={92} height={80} rx={10} fill="#E8F4F8" />
      <rect x={x - 4} y={668} width={100} height={20} rx={6} fill="#E53935" />
      <circle cx={x + 24} cy={740} r={12} fill={c} /><circle cx={x + 52} cy={730} r={12} fill="#FDD835" /><circle cx={x + 70} cy={744} r={12} fill="#43A047" />
    </g>
  );
  return (
    <Svg>
      <g stroke={OL} strokeWidth={5}>
        <rect x="0" y="764" width="1500" height="36" fill="#B07A42" />
        <rect x="0" y="800" width="1500" height="110" fill="#8D5C2E" />
      </g>
      {jar(80, '#E53935')}{jar(210, '#1E88E5')}{jar(1250, '#8E24AA')}{jar(1370, '#FB8C00')}
    </Svg>
  );
};

export const CleanBG: React.FC = () => (
  <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 42%, #FFF9EC 0%, #FBE9C6 68%, #F1D49A 100%)'}} />
);
