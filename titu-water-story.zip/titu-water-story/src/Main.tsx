import React from 'react';
import {AbsoluteFill, Audio, staticFile} from 'remotion';
import {FONT} from './font';
import {Caption} from './UI';
import {S1, S2, S3, S4, S5, S6, S7} from './Scenes';

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: '#000', fontFamily: FONT}}>
    <Audio src={staticFile('voice.mp3')} />
    <S1 /><S2 /><S3 /><S4 /><S5 /><S6 /><S7 />
    <Caption />
  </AbsoluteFill>
);
