# টিটু ও পানির গল্প (Remotion)
npm install
npx remotion studio
npx remotion render TituStory out/titu-water-story.mp4
