import React from 'react';
import {useCurrentFrame} from 'remotion';

const O = '#222222';
const STARS = Array.from({length: 44}, (_, i) => ({x: (i * 397) % 1920, y: (i * 211) % 440, r: 1.5 + (i % 3)}));

export const NightVillage: React.FC<{lit?: boolean; shadowOp?: number}> = ({lit = false, shadowOp = 0}) => (
  <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute', left: 0, top: 0}}>
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#090e2e" />
        <stop offset="1" stopColor="#21407f" />
      </linearGradient>
      <radialGradient id="moonG">
        <stop offset="0" stopColor="#ffffff" stopOpacity={0.85} />
        <stop offset="1" stopColor="#ffffff" stopOpacity={0} />
      </radialGradient>
      <linearGradient id="grd" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#173b27" />
        <stop offset="1" stopColor="#0a1c13" />
      </linearGradient>
    </defs>
    <rect width={1920} height={1080} fill="url(#sky)" />
    {STARS.map((s, i) => <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="#fff" opacity={0.7} />)}
    <circle cx={330} cy={180} r={170} fill="url(#moonG)" />
    <circle cx={330} cy={180} r={66} fill="#f6f3df" stroke={O} strokeWidth={3} />
    <path d="M0 700 Q300 600 600 690 T1200 680 T1920 660 L1920 840 L0 840Z" fill="#0e1b3d" />
    {/* trees */}
    <rect x={110} y={420} width={44} height={420} fill="#2a1a10" stroke={O} strokeWidth={3} />
    <circle cx={130} cy={400} r={150} fill="#0f3322" stroke={O} strokeWidth={3} />
    <circle cx={50} cy={500} r={110} fill="#0c2a1c" stroke={O} strokeWidth={3} />
    <rect x={1768} y={470} width={38} height={370} fill="#2a1a10" stroke={O} strokeWidth={3} />
    <circle cx={1788} cy={450} r={130} fill="#0f3322" stroke={O} strokeWidth={3} />
    {/* house */}
    <path d="M590 430 L760 270 L1200 270 L1370 430Z" fill="#8a4a35" stroke={O} strokeWidth={4} strokeLinejoin="round" />
    <rect x={650} y={430} width={660} height={410} fill="#77746c" stroke={O} strokeWidth={4} />
    <path d="M700 440 L730 520 L700 590 M1250 470 L1220 560 L1260 640" fill="none" stroke="#4a4842" strokeWidth={4} />
    <rect x={900} y={610} width={120} height={230} fill="#07070c" stroke={O} strokeWidth={4} />
    <rect x={720} y={500} width={110} height={130} fill="#0e1424" stroke={O} strokeWidth={4} />
    <line x1={775} y1={500} x2={775} y2={630} stroke={O} strokeWidth={3} />
    <rect x={1160} y={500} width={110} height={130} fill={lit ? '#ffcc66' : '#0e1424'} stroke={O} strokeWidth={4} />
    {lit && shadowOp > 0 && (
      <g opacity={shadowOp} fill="#1a0c00">
        <circle cx={1195} cy={560} r={20} />
        <ellipse cx={1195} cy={625} rx={32} ry={40} />
        <circle cx={1240} cy={566} r={18} />
        <ellipse cx={1240} cy={628} rx={28} ry={38} />
      </g>
    )}
    <line x1={1215} y1={500} x2={1215} y2={630} stroke={O} strokeWidth={3} />
    <rect x={0} y={840} width={1920} height={240} fill="url(#grd)" />
    <ellipse cx={960} cy={960} rx={150} ry={110} fill="#3a2d1f" opacity={0.7} />
  </svg>
);

const MOODS = {
  night: {t: '#1d2c4c', b: '#0d1730', floor: '#2a2118'},
  mirror: {t: '#1a2a38', b: '#0c141c', floor: '#1d1914'},
  dark: {t: '#10162a', b: '#06080f', floor: '#17130f'},
  day: {t: '#d4c4a2', b: '#b09c78', floor: '#8a6a45'},
  red: {t: '#2b1218', b: '#120609', floor: '#1b0f0f'},
};
export type Mood = keyof typeof MOODS;

export const Room: React.FC<{mood: Mood}> = ({mood}) => {
  const c = MOODS[mood];
  return (
    <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute', left: 0, top: 0}}>
      <defs>
        <linearGradient id={`w-${mood}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={c.t} />
          <stop offset="1" stopColor={c.b} />
        </linearGradient>
      </defs>
      <rect width={1920} height={880} fill={`url(#w-${mood})`} />
      <path d="M1500 60 L1530 150 L1490 230 M300 700 L330 760 L300 830 M900 40 L930 110" fill="none" stroke="#000" opacity={0.25} strokeWidth={4} />
      <rect y={850} width={1920} height={230} fill={c.floor} />
      {Array.from({length: 9}).map((_, i) => <line key={i} x1={0} x2={1920} y1={880 + i * 26} y2={880 + i * 26} stroke="#000" opacity={0.22} strokeWidth={3} />)}
      <rect y={838} width={1920} height={18} fill="#000" opacity={0.35} />
    </svg>
  );
};

export const WindowFrame: React.FC<{x: number; y: number; w: number; h: number; day?: boolean}> = ({x, y, w, h, day = false}) => (
  <svg width={w + 40} height={h + 40} style={{position: 'absolute', left: x - 20, top: y - 20}}>
    <rect x={20} y={20} width={w} height={h} fill={day ? '#fff6c8' : '#1c3566'} stroke="#3b2616" strokeWidth={14} />
    <line x1={20 + w / 2} y1={20} x2={20 + w / 2} y2={20 + h} stroke="#3b2616" strokeWidth={10} />
    <line x1={20} y1={20 + h / 2} x2={20 + w} y2={20 + h / 2} stroke="#3b2616" strokeWidth={10} />
    {!day && <circle cx={20 + w * 0.28} cy={20 + h * 0.3} r={34} fill="#f6f3df" opacity={0.9} />}
  </svg>
);

export const Bed: React.FC<{x: number; y: number; w: number}> = ({x, y, w}) => (
  <svg width={w + 60} height={320} style={{position: 'absolute', left: x - 30, top: y - 190}}>
    <rect x={30} y={0} width={34} height={320} rx={10} fill="#4a2f1a" stroke={O} strokeWidth={4} />
    <rect x={30} y={150} width={w} height={60} rx={14} fill="#e8e0d0" stroke={O} strokeWidth={4} />
    <rect x={30} y={205} width={w} height={90} rx={10} fill="#5a3a22" stroke={O} strokeWidth={4} />
    <ellipse cx={130} cy={150} rx={80} ry={30} fill="#c0392b" stroke={O} strokeWidth={4} />
  </svg>
);
export const Blanket: React.FC<{x: number; y: number; w: number; h: number; color?: string}> = ({x, y, w, h, color = '#1b3fb5'}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, background: color, border: `4px solid ${O}`, borderRadius: 24, boxShadow: 'inset 0 -20px 40px rgba(0,0,0,0.25)'}} />
);

export const Lantern: React.FC<{x: number; y: number}> = ({x, y}) => {
  const fr = useCurrentFrame();
  const g = 0.55 + Math.sin(fr / 5) * 0.08 + Math.sin(fr / 11) * 0.06;
  return (
    <svg width={500} height={500} style={{position: 'absolute', left: x - 250, top: y - 300}}>
      <defs>
        <radialGradient id="lg">
          <stop offset="0" stopColor="#ffb84a" stopOpacity={g} />
          <stop offset="1" stopColor="#ffb84a" stopOpacity={0} />
        </radialGradient>
      </defs>
      <circle cx={250} cy={300} r={230} fill="url(#lg)" />
      <rect x={225} y={260} width={50} height={64} rx={8} fill="#ffcf6e" stroke={O} strokeWidth={4} />
      <rect x={220} y={252} width={60} height={10} fill="#333" stroke={O} strokeWidth={3} />
      <rect x={220} y={324} width={60} height={10} fill="#333" stroke={O} strokeWidth={3} />
      <rect x={200} y={334} width={100} height={90} fill="#4a2f1a" stroke={O} strokeWidth={4} />
    </svg>
  );
};
