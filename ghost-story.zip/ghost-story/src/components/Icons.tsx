import React from 'react';
import {interpolate, spring, useVideoConfig} from 'remotion';
import {useGT} from '../timing';
import {FONT} from './font';

export const Pop: React.FC<{a: number; b: number; x: number; y: number; s?: number; children: React.ReactNode}> = ({a, b, x, y, s = 1, children}) => {
  const t = useGT();
  const {fps} = useVideoConfig();
  if (t < a || t > b) return null;
  const sp = spring({frame: (t - a) * fps, fps, config: {damping: 11, stiffness: 140}});
  const out = interpolate(t, [b - 0.25, b], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const fl = Math.sin(t * 3) * 8;
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) translateY(${fl}px) scale(${sp * out * s})`}}>
      {children}
    </div>
  );
};

const O = '#222222';
export const ClockIcon: React.FC = () => {
  const t = useGT();
  return (
    <svg width={190} height={190} viewBox="0 0 100 100">
      <circle cx={50} cy={50} r={44} fill="#fffbe8" stroke={O} strokeWidth={4} />
      {[0, 90, 180, 270].map((r) => <line key={r} x1={50} y1={10} x2={50} y2={18} stroke={O} strokeWidth={4} transform={`rotate(${r} 50 50)`} />)}
      <line x1={50} y1={50} x2={50} y2={22} stroke={O} strokeWidth={5} strokeLinecap="round" transform={`rotate(${t * 40} 50 50)`} />
      <line x1={50} y1={50} x2={50} y2={30} stroke="#d2232a" strokeWidth={5} strokeLinecap="round" transform={`rotate(${t * 480} 50 50)`} />
      <circle cx={50} cy={50} r={4} fill={O} />
    </svg>
  );
};
export const WarnIcon: React.FC = () => (
  <svg width={170} height={170} viewBox="0 0 100 100">
    <path d="M50 8 L94 88 L6 88Z" fill="#ffd34d" stroke={O} strokeWidth={5} strokeLinejoin="round" />
    <rect x={46} y={36} width={8} height={30} rx={4} fill={O} />
    <circle cx={50} cy={77} r={5} fill={O} />
  </svg>
);
export const QuestionIcon: React.FC = () => (
  <svg width={150} height={150} viewBox="0 0 100 100">
    <circle cx={50} cy={50} r={44} fill="#6c8cff" stroke={O} strokeWidth={5} />
    <text x={50} y={74} textAnchor="middle" fontSize={70} fontWeight={700} fontFamily={FONT} fill="#fff">?</text>
  </svg>
);
export const HeartIcon: React.FC = () => {
  const t = useGT();
  const k = 1 + 0.16 * Math.max(0, Math.sin(t * 9)) ** 3;
  return (
    <svg width={150} height={150} viewBox="0 0 100 100" style={{transform: `scale(${k})`}}>
      <path d="M50 88 C10 56 6 28 28 20 C40 16 48 24 50 32 C52 24 60 16 72 20 C94 28 90 56 50 88Z" fill="#e5283b" stroke={O} strokeWidth={5} strokeLinejoin="round" />
    </svg>
  );
};
export const SunIcon: React.FC = () => {
  const t = useGT();
  return (
    <svg width={190} height={190} viewBox="0 0 100 100">
      <g transform={`rotate(${t * 30} 50 50)`}>
        {Array.from({length: 10}).map((_, i) => <line key={i} x1={50} y1={6} x2={50} y2={20} stroke="#ffb400" strokeWidth={6} strokeLinecap="round" transform={`rotate(${i * 36} 50 50)`} />)}
      </g>
      <circle cx={50} cy={50} r={24} fill="#ffd34d" stroke={O} strokeWidth={4} />
    </svg>
  );
};
export const WavesIcon: React.FC = () => {
  const t = useGT();
  return (
    <svg width={220} height={160} viewBox="0 0 110 80">
      {[0, 1, 2].map((i) => {
        const p = (t * 1.2 + i / 3) % 1;
        return <path key={i} d="M30 10 Q55 40 30 70" fill="none" stroke="#8fd3ff" strokeWidth={5} strokeLinecap="round" opacity={1 - p} transform={`translate(${p * 40} 0)`} />;
      })}
      <circle cx={16} cy={40} r={9} fill="#8fd3ff" stroke={O} strokeWidth={3} />
    </svg>
  );
};
export const ZzzIcon: React.FC = () => (
  <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 110, color: '#cfe2ff', textShadow: '4px 4px 0 #222', letterSpacing: 6}}>Z<span style={{fontSize: 80}}>z</span><span style={{fontSize: 56}}>z</span></div>
);
