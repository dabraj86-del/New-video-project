import React from 'react';
import {useCurrentFrame} from 'remotion';

export type Kind = 'roni' | 'uncle' | 'ghost';
export type Expr = 'normal' | 'scared' | 'shock' | 'worry' | 'angry' | 'creepy' | 'smile' | 'calm';

const OUT = '#222222';
const SW = 2.5;
const PAL = {
  roni: {skin: '#e7b08a', shirt: '#1f3fd1', pants: '#262c55', hair: '#16110f', shoe: '#222222'},
  uncle: {skin: '#d9a27a', shirt: '#efe6d2', pants: '#e4dcc8', hair: '#d7d7d7', shoe: '#5a4632'},
  ghost: {skin: '#d9d7e6', shirt: '#efece8', pants: '#efece8', hair: '#0b0b0e', shoe: '#efece8'},
};
const st = {stroke: OUT, strokeWidth: SW, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

const BROWS: Record<string, number[][]> = {
  normal: [[145, 160, 185, 156], [215, 156, 255, 160]],
  worry: [[145, 166, 185, 146], [215, 146, 255, 166]],
  angry: [[145, 148, 185, 166], [215, 166, 255, 148]],
};
const browKey = (e: Expr) =>
  e === 'scared' || e === 'shock' || e === 'worry' ? 'worry' : e === 'angry' || e === 'creepy' ? 'angry' : 'normal';

const Face: React.FC<{kind: Kind; expr: Expr; m: number; blink: boolean; black: boolean}> = ({kind, expr, m, blink, black}) => {
  const dark = kind === 'ghost' || black;
  const big = expr === 'scared' || expr === 'shock';
  const ry = blink ? 2 : big ? 27 : 20;
  const rx = big ? 20 : 18;
  const pr = big ? 4.5 : 8;
  const [bl, br] = BROWS[browKey(expr)];
  let mouth: React.ReactNode;
  if (m === 1) mouth = <ellipse cx={200} cy={252} rx={14} ry={8} fill="#6b1d1d" {...st} />;
  else if (m === 2) mouth = <ellipse cx={200} cy={254} rx={20} ry={17} fill="#6b1d1d" {...st} />;
  else if (expr === 'scared' || expr === 'shock') mouth = <ellipse cx={200} cy={258} rx={16} ry={22} fill="#6b1d1d" {...st} />;
  else if (expr === 'smile') mouth = <path d="M168 244 Q200 282 232 244 Z" fill="#fff" {...st} />;
  else if (expr === 'creepy')
    mouth = (
      <>
        <path d="M150 238 Q200 306 250 238 Z" fill="#2a0707" {...st} />
        <path d="M160 252 L170 266 L180 254 L190 270 L200 256 L210 270 L220 254 L230 266 L240 252" fill="none" stroke="#fff" strokeWidth={4} />
      </>
    );
  else if (expr === 'worry' || expr === 'angry') mouth = <path d="M176 260 Q200 244 224 260" fill="none" {...st} />;
  else mouth = <path d="M176 250 Q200 258 224 250" fill="none" {...st} />;

  const eye = (cx: number) => (
    <g key={cx}>
      {dark && <ellipse cx={cx} cy={188} rx={27} ry={29} fill="#3a2f45" opacity={0.55} />}
      <ellipse cx={cx} cy={188} rx={rx} ry={ry} fill={dark ? '#08080a' : '#fff'} {...st} />
      {!blink && (dark ? <circle cx={cx + 6} cy={181} r={3.5} fill="#fff" /> : <circle cx={cx + 3} cy={190} r={pr} fill="#222" />)}
    </g>
  );
  return (
    <g>
      {eye(165)}
      {eye(235)}
      <line x1={bl[0]} y1={bl[1]} x2={bl[2]} y2={bl[3]} stroke={OUT} strokeWidth={7} strokeLinecap="round" />
      <line x1={br[0]} y1={br[1]} x2={br[2]} y2={br[3]} stroke={OUT} strokeWidth={7} strokeLinecap="round" />
      {mouth}
      {big && <path d="M292 140 Q302 160 292 168 Q282 160 292 140Z" fill="#8fd3ff" {...st} />}
    </g>
  );
};

export type PersonProps = {
  kind: Kind;
  x: number; // center x on screen
  y: number; // top y on screen
  scale?: number;
  flip?: boolean;
  expr?: Expr;
  talk?: boolean;
  bust?: boolean;
  back?: boolean;
  rot?: number;
  armL?: number;
  armR?: number;
  shake?: number;
  walk?: boolean;
  opacity?: number;
  silhouette?: boolean;
  eyesBlack?: boolean;
  bag?: boolean;
  floatAmp?: number;
  seed?: number;
};

export const Person: React.FC<PersonProps> = (p) => {
  const {kind, x, y, scale = 1, flip = false, expr = 'normal', talk = false, bust = false, back = false, rot = 0, armL = 0, armR = 0, shake = 0, walk = false, opacity = 1, silhouette = false, eyesBlack = false, bag = false, floatAmp = 5, seed = 0} = p;
  const frame = useCurrentFrame();
  const pal = PAL[kind];
  const fl = Math.sin((frame + seed * 20) / 16) * floatAmp;
  const jx = shake ? Math.sin(frame * 2.9) * shake : 0;
  const jy = shake ? Math.cos(frame * 3.7) * shake * 0.6 : 0;
  const blink = (frame + seed * 37) % 110 < 4;
  const m = talk ? [0, 1, 2, 1, 2, 0][Math.floor(frame / 3) % 6] : 0;
  const sw = walk ? Math.sin(frame / 3.2) * 20 : 0;
  const H = bust ? 520 : 720;
  const hb = bust ? 515 : 560;
  const isGhost = kind === 'ghost';

  return (
    <svg
      width={400 * scale}
      height={H * scale}
      viewBox={`0 0 400 ${H}`}
      style={{
        position: 'absolute',
        left: x - 200 * scale,
        top: y,
        opacity,
        overflow: 'visible',
        transform: `translate(${jx}px, ${fl + jy}px) rotate(${rot}deg) scaleX(${flip ? -1 : 1})`,
        filter: silhouette ? 'brightness(0.16)' : undefined,
      }}
    >
      <defs>
        <pattern id="chk" width="26" height="26" patternUnits="userSpaceOnUse">
          <rect width="26" height="26" fill="#fff" />
          <rect width="13" height="26" fill="#d2232a" opacity={0.85} />
          <rect width="26" height="13" fill="#d2232a" opacity={0.55} />
        </pattern>
      </defs>

      {isGhost && <path d={`M105 150 Q55 350 85 ${hb} L315 ${hb} Q345 350 295 150Z`} fill={pal.hair} {...st} />}

      {!bust && !isGhost && (
        <>
          <g transform={`rotate(${sw} 162 480)`}>
            <rect x={135} y={470} width={54} height={215} rx={27} fill={pal.pants} {...st} />
            <ellipse cx={162} cy={688} rx={36} ry={14} fill={pal.shoe} {...st} />
          </g>
          <g transform={`rotate(${-sw} 238 480)`}>
            <rect x={211} y={470} width={54} height={215} rx={27} fill={pal.pants} {...st} />
            <ellipse cx={238} cy={688} rx={36} ry={14} fill={pal.shoe} {...st} />
          </g>
        </>
      )}
      {!bust && isGhost && <path d="M120 430 Q105 600 90 705 L310 705 Q295 600 280 430Z" fill={pal.shirt} {...st} />}

      <rect x={120} y={265} width={160} height={230} rx={55} fill={pal.shirt} {...st} />
      {kind === 'roni' && (
        <>
          <path d="M175 268 L200 305 L225 268" fill="#fff" {...st} />
          <line x1={200} y1={305} x2={200} y2={480} stroke="#162a8f" strokeWidth={3} />
          {bag && <path d="M135 275 L268 478" stroke="#6b4423" strokeWidth={16} strokeLinecap="round" />}
        </>
      )}
      {kind === 'uncle' && (
        <>
          <line x1={200} y1={290} x2={200} y2={480} stroke="#b9ad90" strokeWidth={3} />
          <path d="M122 290 L170 272 L282 462 L236 490Z" fill="url(#chk)" {...st} />
        </>
      )}
      {isGhost && (
        <>
          <path d="M120 300 Q200 280 280 420 L280 495 L215 495Z" fill="#fff" {...st} />
          <circle cx={170} cy={400} r={9} fill="#9b1c1c" opacity={0.8} />
          <circle cx={235} cy={450} r={13} fill="#9b1c1c" opacity={0.8} />
          <circle cx={150} cy={330} r={6} fill="#9b1c1c" opacity={0.8} />
          {!bust && <circle cx={180} cy={600} r={14} fill="#9b1c1c" opacity={0.75} />}
        </>
      )}

      <g transform={`rotate(${armL} 130 300)`}>
        <rect x={108} y={288} width={44} height={178} rx={22} fill={pal.shirt} {...st} />
        <circle cx={130} cy={470} r={24} fill={pal.skin} {...st} />
      </g>
      <g transform={`rotate(${armR} 270 300)`}>
        <rect x={248} y={288} width={44} height={178} rx={22} fill={pal.shirt} {...st} />
        <circle cx={270} cy={470} r={24} fill={pal.skin} {...st} />
      </g>

      <rect x={178} y={252} width={44} height={36} fill={pal.skin} {...st} />

      {back ? (
        <>
          <ellipse cx={114} cy={200} rx={14} ry={18} fill={pal.skin} {...st} />
          <ellipse cx={286} cy={200} rx={14} ry={18} fill={pal.skin} {...st} />
          <ellipse cx={200} cy={186} rx={92} ry={102} fill={pal.hair} {...st} />
          <path d="M150 96 Q128 60 172 76Z M215 84 Q232 50 258 90Z" fill={pal.hair} {...st} />
        </>
      ) : (
        <>
          <circle cx={114} cy={195} r={16} fill={pal.skin} {...st} />
          <circle cx={286} cy={195} r={16} fill={pal.skin} {...st} />
          <ellipse cx={200} cy={190} rx={86} ry={96} fill={pal.skin} {...st} />
          {kind === 'roni' && (
            <>
              <path d="M112 175 Q98 80 200 74 Q302 80 288 175 Q272 122 238 128 Q214 100 176 128 Q130 120 112 175Z" fill={pal.hair} {...st} />
              <path d="M150 92 Q128 58 172 76Z M222 80 Q240 48 262 90Z" fill={pal.hair} {...st} />
              <path d="M140 262 Q200 290 260 262 Q240 276 200 278 Q160 276 140 262Z" fill="#3a2a22" opacity={0.35} />
            </>
          )}
          {kind === 'uncle' && (
            <>
              <path d="M116 178 Q108 118 150 106 Q200 90 250 106 Q292 118 284 178 Q268 130 200 128 Q132 130 116 178Z" fill={pal.hair} {...st} />
              <path d="M120 205 Q125 300 200 306 Q275 300 280 205 Q265 258 200 264 Q135 258 120 205Z" fill="#f2f2f2" {...st} />
            </>
          )}
          {isGhost && <path d="M104 175 Q100 78 200 74 Q300 78 296 175 Q262 112 200 150 Q138 112 104 175Z" fill={pal.hair} {...st} />}
          <Face kind={kind} expr={expr} m={m} blink={blink} black={eyesBlack} />
          {kind === 'uncle' && <path d="M162 243 Q200 226 238 243 Q200 252 162 243Z" fill="#f2f2f2" {...st} />}
        </>
      )}
      {isGhost && (
        <>
          <path d={`M110 170 Q62 330 92 ${hb - 30} L138 ${hb - 30} Q116 330 140 200Z`} fill={pal.hair} {...st} />
          <path d={`M290 170 Q338 330 308 ${hb - 30} L262 ${hb - 30} Q284 330 260 200Z`} fill={pal.hair} {...st} />
        </>
      )}
    </svg>
  );
};
