import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT} from './font';
import {CAPS, DLG, Dlg, END_START, SCENES, STAMPS, StampInfo, captionBusy, FPS} from '../timing';

const BN = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
const bn = (n: number) => String(n).split('').map((c) => BN[+c]).join('');
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// ---- Scene title pill (floating overlay at the top) ----
const TitlePill: React.FC<{t: number}> = ({t}) => {
  const {fps} = useVideoConfig();
  const s = SCENES.find((x) => t >= x.start && t < x.titleEnd);
  if (!s) return null;
  const a = t - s.start;
  const sp = spring({frame: a * fps, fps, config: {damping: 14}});
  const out = interpolate(t, [s.titleEnd - 0.3, s.titleEnd], [1, 0], clamp);
  return (
    <div
      style={{
        position: 'absolute', top: 46, left: 0, right: 0, display: 'flex', justifyContent: 'center',
        transform: `translateY(${(1 - sp) * -80}px)`, opacity: out,
      }}
    >
      <div
        style={{
          fontFamily: FONT, fontWeight: 700, fontSize: 52, color: '#fff', padding: '12px 44px', borderRadius: 60,
          background: 'rgba(15,12,25,0.78)', border: '3px solid #ff5a5a', boxShadow: '0 6px 24px rgba(0,0,0,0.5)',
        }}
      >
        <span style={{color: '#ff7a7a'}}>দৃশ্য {bn(s.id)}</span> • {s.title}
      </div>
    </div>
  );
};

// ---- Dialogue callout bubble ----
const NAMES: Record<string, string> = {roni: 'রনি', uncle: 'চাচা', ghost: 'মেয়েটি', evil: 'মেয়েটি'};
const Bubble: React.FC<{d: Dlg; t: number}> = ({d, t}) => {
  const {fps} = useVideoConfig();
  const sp = spring({frame: (t - d.a) * fps, fps, config: {damping: 13, stiffness: 160}});
  const out = interpolate(t, [d.b + 0.05, d.b + 0.3], [1, 0], clamp);
  const dark = d.who === 'ghost' || d.who === 'evil';
  const bg = dark ? '#1a0f22' : d.who === 'roni' ? '#e6eeff' : '#fffaf0';
  const border = dark ? '#ff4d4d' : '#222222';
  const tag = d.who === 'roni' ? '#1f3fd1' : d.who === 'uncle' ? '#c27a2c' : '#b3202a';
  return (
    <div
      style={{
        position: 'absolute', left: d.bx, bottom: 1080 - d.by, width: d.w, opacity: out,
        transform: `scale(${0.6 + 0.4 * sp})`, transformOrigin: `${d.tail + 25}px 100%`,
      }}
    >
      <div
        style={{
          position: 'relative', background: bg, border: `5px solid ${border}`, borderRadius: 38, padding: '34px 36px 24px',
          fontFamily: FONT, fontWeight: 700, fontSize: 54, lineHeight: 1.3, color: dark ? '#ffe3e3' : '#1b1b1b',
          boxShadow: '0 8px 28px rgba(0,0,0,0.45)',
        }}
      >
        <div
          style={{
            position: 'absolute', top: -26, left: 28, background: tag, color: '#fff', fontSize: 30,
            padding: '2px 22px', borderRadius: 30, border: '3px solid #222',
          }}
        >
          {NAMES[d.who]}
        </div>
        {d.text}
      </div>
      <svg width={50} height={40} style={{position: 'absolute', left: d.tail, top: '100%', marginTop: -6, overflow: 'visible'}}>
        <path d="M0 0 L25 40 L50 0" fill={bg} stroke={border} strokeWidth={5} strokeLinejoin="round" />
        <rect x={3} y={-3} width={44} height={8} fill={bg} />
      </svg>
    </div>
  );
};

// ---- Bold stamp badge ----
const Stamp: React.FC<{s: StampInfo; t: number}> = ({s, t}) => {
  const {fps} = useVideoConfig();
  const sp = spring({frame: (t - s.a) * fps, fps, config: {damping: 9, stiffness: 220}});
  const out = interpolate(t, [s.b - 0.2, s.b], [1, 0], clamp);
  return (
    <div
      style={{
        position: 'absolute', left: s.x, top: s.y, opacity: out,
        transform: `translate(-50%,-50%) rotate(${s.rot}deg) scale(${2.4 - 1.4 * sp})`,
      }}
    >
      <div
        style={{
          fontFamily: FONT, fontWeight: 700, fontSize: 118, color: s.color, padding: '6px 54px', borderRadius: 24,
          border: `10px solid ${s.color}`, background: 'rgba(8,6,14,0.82)', whiteSpace: 'nowrap',
          boxShadow: `0 0 40px ${s.color}88`,
        }}
      >
        {s.text}
      </div>
    </div>
  );
};

// ---- Bottom caption (floating over the full-screen scene) ----
const Caption: React.FC<{text: string; a: number; b: number; t: number}> = ({text, a, b, t}) => {
  const up = interpolate(t, [a, a + 0.25], [30, 0], clamp);
  const op = interpolate(t, [a, a + 0.25, b - 0.15, b], [0, 1, 1, 0], clamp);
  const parts = text.split(/(\[\[.*?\]\])/g).filter(Boolean);
  return (
    <div style={{position: 'absolute', bottom: 70, left: 0, right: 0, display: 'flex', justifyContent: 'center', opacity: op, transform: `translateY(${up}px)`}}>
      <div
        style={{
          fontFamily: FONT, fontSize: 66, fontWeight: 400, color: '#fff', padding: '10px 44px', borderRadius: 60,
          background: 'rgba(0,0,0,0.58)', whiteSpace: 'nowrap', textShadow: '0 2px 6px rgba(0,0,0,0.8)',
        }}
      >
        {parts.map((p, i) =>
          p.startsWith('[[') ? (
            <span key={i} style={{color: '#ffd34d', fontWeight: 700}}>{p.slice(2, -2)}</span>
          ) : (
            <span key={i}>{p}</span>
          ),
        )}
      </div>
    </div>
  );
};

export const Overlay: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const cap = !captionBusy(t) ? CAPS.find((c) => t >= c.a && t < c.b) : undefined;
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {t < END_START && <TitlePill t={t} />}
      {t < END_START && DLG.filter((d) => t >= d.a && t <= d.b + 0.3).map((d) => <Bubble key={d.a} d={d} t={t} />)}
      {t < END_START && STAMPS.filter((s) => t >= s.a && t <= s.b).map((s) => <Stamp key={s.a} s={s} t={t} />)}
      {cap && <Caption key={cap.a} text={cap.text} a={cap.a} b={cap.b} t={t} />}
    </AbsoluteFill>
  );
};
