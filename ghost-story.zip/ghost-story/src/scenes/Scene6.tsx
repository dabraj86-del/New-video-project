import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {Person} from '../components/Person';
import {Room, NightVillage} from '../components/Backgrounds';
import {Pop, WarnIcon, WavesIcon, HeartIcon} from '../components/Icons';
import {FONT} from '../components/font';
import {END_START, ramp, speaking, useGT} from '../timing';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const EndCard: React.FC<{t: number}> = ({t}) => {
  const fin = ramp(t, END_START, END_START + 0.6);
  const l1 = ramp(t, 211.1, 211.7);
  const l2 = ramp(t, 216.38, 216.9);
  const l3 = ramp(t, 217.64, 218.2);
  const ghostOp = ramp(t, 217.64, 219.0);
  const ft = {fontFamily: FONT, color: '#fff', textAlign: 'center' as const};
  return (
    <AbsoluteFill style={{opacity: fin, background: 'radial-gradient(ellipse at center, #1a0a12 0%, #000 75%)'}}>
      {t < 211.1 && (
        <div style={{...ft, position: 'absolute', top: 400, width: '100%', fontSize: 150, fontWeight: 700, opacity: ramp(t, 210.2, 210.7), letterSpacing: 8}}>সমাপ্তি</div>
      )}
      {t >= 211.1 && (
        <>
          <div style={{position: 'absolute', top: 70, width: '100%', display: 'flex', justifyContent: 'center', opacity: l1}}>
            <div style={{...ft, fontWeight: 700, fontSize: 52, padding: '8px 44px', borderRadius: 60, background: '#8f1520', border: '3px solid #ff6b6b'}}>ভয়ংকর শেষ কথা</div>
          </div>
          <div style={{...ft, position: 'absolute', top: 200, left: 160, right: 160, fontSize: 68, lineHeight: 1.4, opacity: l1, transform: `translateY(${(1 - l1) * 30}px)`}}>
            আপনি যদি কোনো রাতে নিজের <span style={{color: '#ffd34d', fontWeight: 700}}>ছায়া</span> দেখতে না পান, তাহলে <span style={{color: '#ffd34d', fontWeight: 700}}>পেছনে তাকাবেন না।</span>
          </div>
          <div style={{...ft, position: 'absolute', top: 430, left: 160, right: 160, fontSize: 62, opacity: l2, color: '#bbb'}}>কারণ হতে পারে...</div>
          <div style={{...ft, position: 'absolute', top: 530, left: 120, right: 120, fontSize: 80, fontWeight: 700, opacity: l3, color: '#ff4d4d', transform: `scale(${0.9 + 0.1 * l3})`, textShadow: '0 0 30px #ff0000aa'}}>
            আপনার ছায়াটা আপনার পেছনেই দাঁড়িয়ে আছে!
          </div>
          <Person kind="ghost" x={1010} y={690} scale={0.5} bust silhouette opacity={ghostOp * 0.9} floatAmp={6} />
          <Person kind="roni" x={900} y={700} scale={0.5} bust silhouette opacity={ghostOp * 0.9} back />
        </>
      )}
    </AbsoluteFill>
  );
};

export const Scene6: React.FC = () => {
  const t = useGT();
  const uncleX = interpolate(t, [171.28, 174.0], [380, 250], cl);
  const rOp = ramp(t, 174.0, 175.4);
  const close = ramp(t, 195.46, 196.3) * 225;
  const interior = t < 197.8;
  const shadows = ramp(t, 201.4, 202.2);
  const gExpr = t >= 187.7 ? 'creepy' : 'smile';
  return (
    <AbsoluteFill>
      {interior ? (
        <>
          <Room mood="red" />
          <div style={{position: 'absolute', left: 1180, top: 120, width: 640, height: 760, background: 'radial-gradient(circle, rgba(255,40,40,0.35), transparent 70%)'}} />
          {/* doorway to outside */}
          <div style={{position: 'absolute', left: 700, top: 140, width: 450, height: 760, border: '10px solid #3b2616', background: 'linear-gradient(180deg,#1b2a5a,#0b1230)', overflow: 'hidden'}}>
            <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 120, background: '#0c1f16'}} />
          </div>
          <Person kind="roni" x={925} y={260} scale={0.75} opacity={rOp} expr="scared" talk={speaking('roni', t)} shake={2.5} armL={150} armR={-150} bag />
          <div style={{position: 'absolute', left: 710, top: 150, width: close, height: 740, background: '#4a2f1a', borderRight: '6px solid #222'}} />
          <div style={{position: 'absolute', left: 1140 - close, top: 150, width: close, height: 740, background: '#4a2f1a', borderLeft: '6px solid #222'}} />
          <Person kind="ghost" bust x={1500} y={250} scale={1.2} flip expr={gExpr} talk={speaking('ghost', t)} armR={-110} floatAmp={8} />
          <Person kind="uncle" bust x={uncleX} y={480} expr="shock" shake={2.5} armL={30} armR={-30} seed={4} />
          <Pop a={171.3} b={174.0} x={560} y={330}><WarnIcon /></Pop>
          <Pop a={174.0} b={178.0} x={925} y={80}><WavesIcon /></Pop>
          <Pop a={183.9} b={185.7} x={520} y={330}><HeartIcon /></Pop>
        </>
      ) : (
        <NightVillage lit shadowOp={shadows} />
      )}
      {t >= END_START && <EndCard t={t} />}
    </AbsoluteFill>
  );
};
