import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {Person} from '../components/Person';
import {Room} from '../components/Backgrounds';
import {Pop, HeartIcon, WarnIcon} from '../components/Icons';
import {ramp, speaking, useGT} from '../timing';

export const Scene3: React.FC = () => {
  const t = useGT();
  const turn = ramp(t, 88.46, 94.0);
  const gScale = interpolate(turn, [0, 1], [0.8, 1.1]);
  const gY = interpolate(turn, [0, 1], [190, 70]);
  const gExpr = t >= 88.46 ? 'creepy' : 'calm';
  const flick = t >= 97.4 && t < 99.2 ? 0.55 * Math.abs(Math.sin(t * 40)) : 0;
  return (
    <AbsoluteFill>
      <Room mood="mirror" />
      <div style={{position: 'absolute', left: 860, top: 250, width: 540, height: 700, background: '#4a2f1a', border: '6px solid #222', borderRadius: '270px 270px 24px 24px'}} />
      <div style={{position: 'absolute', left: 900, top: 290, width: 460, height: 620, overflow: 'hidden', borderRadius: '230px 230px 10px 10px', border: '4px solid #222', background: 'linear-gradient(180deg,#223a4a,#0f1c26)'}}>
        <Person kind="ghost" bust x={230} y={gY} scale={gScale} expr={gExpr} talk={speaking('ghost', t)} floatAmp={4} />
        <svg width={460} height={620} style={{position: 'absolute', left: 0, top: 0}}>
          <path d="M60 120 L200 300 L150 480 M380 60 L300 220" stroke="#fff" opacity={0.18} strokeWidth={3} fill="none" />
        </svg>
      </div>
      <Person kind="roni" bust back={t < 85.5} x={450} y={300} scale={1.25} expr="scared" talk={speaking('roni', t)} />
      <Pop a={78.6} b={83.2} x={760} y={330}><HeartIcon /></Pop>
      <Pop a={90.9} b={94.6} x={1600} y={420}><WarnIcon /></Pop>
      <AbsoluteFill style={{background: '#000', opacity: flick}} />
    </AbsoluteFill>
  );
};
