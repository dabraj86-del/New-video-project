import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {Person} from '../components/Person';
import {Room, WindowFrame, Bed, Blanket, Lantern} from '../components/Backgrounds';
import {Pop, WavesIcon, HeartIcon, QuestionIcon} from '../components/Icons';
import {ramp, useGT} from '../timing';
import {useCurrentFrame} from 'remotion';

export const Scene2: React.FC = () => {
  const t = useGT();
  const fr = useCurrentFrame();
  const lying = t < 45.84;
  const sitting = t >= 45.84 && t < 54.6;
  const standing = t >= 54.6;
  const rx = interpolate(t, [54.6, 57.0], [560, 1220], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const walking = t > 54.6 && t < 57.0;
  const gap = ramp(t, 57.0, 57.6);
  const rExpr = t >= 65.5 && t < 67.4 ? 'shock' : standing || t >= 48 ? 'scared' : sitting ? 'worry' : 'calm';
  return (
    <AbsoluteFill>
      <Room mood="night" />
      <WindowFrame x={220} y={170} w={300} h={300} />
      <Bed x={140} y={800} w={860} />
      <Lantern x={1100} y={800} />
      {/* door */}
      <div style={{position: 'absolute', left: 1380, top: 230, width: 340, height: 610, background: '#050a14', border: '8px solid #2a1a10'}}>
        <div style={{position: 'absolute', inset: 0, background: `radial-gradient(circle at 10% 50%, rgba(110,160,255,${0.15 + gap * 0.5}), transparent 70%)`}} />
        {gap > 0 && (
          <div style={{position: 'absolute', left: 14, top: 230, opacity: gap * (0.75 + 0.25 * Math.sin(fr / 4))}}>
            <svg width={60} height={30}>
              <ellipse cx={14} cy={15} rx={11} ry={9} fill="#fff" stroke="#b3202a" strokeWidth={3} />
              <ellipse cx={46} cy={15} rx={11} ry={9} fill="#fff" stroke="#b3202a" strokeWidth={3} />
              <circle cx={16} cy={15} r={3} fill="#000" />
              <circle cx={48} cy={15} r={3} fill="#000" />
            </svg>
          </div>
        )}
        <div style={{position: 'absolute', left: 36 * gap, top: 0, right: 0, bottom: 0, background: 'linear-gradient(90deg,#5a3a22,#4a2f1a)', borderLeft: '6px solid #222', transform: `skewY(${-gap * 1.5}deg)`}}>
          <div style={{position: 'absolute', left: 30, top: 60, width: 220, height: 200, border: '5px solid #2a1a10', borderRadius: 8}} />
          <div style={{position: 'absolute', left: 30, top: 320, width: 220, height: 210, border: '5px solid #2a1a10', borderRadius: 8}} />
          <div style={{position: 'absolute', left: 14, top: 300, width: 22, height: 22, borderRadius: 11, background: '#d9a94a', border: '3px solid #222'}} />
        </div>
      </div>
      {lying && <Person kind="roni" bust x={520} y={500} rot={-86} expr="calm" floatAmp={3} />}
      {sitting && <Person kind="roni" bust x={560} y={380} expr={rExpr} shake={t > 48.7 ? 1.5 : 0} />}
      <Blanket x={lying ? 600 : 140} y={lying ? 720 : 770} w={lying ? 400 : 860} h={lying ? 120 : 110} />
      {standing && <Person kind="roni" x={rx} y={300} walk={walking} expr={rExpr} shake={t > 57 ? 2 : 0} />}
      <Pop a={48.7} b={54.6} x={1550} y={150}><WavesIcon /></Pop>
      <Pop a={54.6} b={57.2} x={1020} y={330}><HeartIcon /></Pop>
      <Pop a={65.5} b={67.3} x={1230} y={260}><QuestionIcon /></Pop>
    </AbsoluteFill>
  );
};
