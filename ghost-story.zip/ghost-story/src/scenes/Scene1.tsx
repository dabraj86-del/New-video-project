import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {Person} from '../components/Person';
import {NightVillage} from '../components/Backgrounds';
import {Pop, WarnIcon, ClockIcon, QuestionIcon, ZzzIcon} from '../components/Icons';
import {ramp, speaking, useGT} from '../timing';

export const Scene1: React.FC = () => {
  const t = useGT();
  const rx = interpolate(t, [14.96, 17.6], [-250, 520], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const walking = t > 14.96 && t < 17.6;
  const eld = ramp(t, 8.84, 9.5) * (1 - ramp(t, 14.4, 14.96));
  const uncleOp = ramp(t, 19.2, 19.8);
  const pointing = t >= 24.44 && t < 31;
  const uExpr = t >= 33.18 ? 'worry' : 'normal';
  const rExpr = t >= 33 ? 'scared' : t >= 30.36 ? 'worry' : 'normal';
  return (
    <AbsoluteFill>
      <NightVillage />
      {eld > 0 && (
        <>
          <Person kind="uncle" x={1050} y={520} scale={0.5} silhouette opacity={eld * 0.9} seed={1} />
          <Person kind="uncle" x={1230} y={540} scale={0.46} silhouette opacity={eld * 0.9} seed={2} />
        </>
      )}
      <Person kind="roni" x={rx} y={330} scale={0.95} bag walk={walking} expr={rExpr} talk={speaking('roni', t)} />
      <Person kind="uncle" x={1380} y={330} scale={0.95} flip opacity={uncleOp} expr={uExpr} talk={speaking('uncle', t)} armR={pointing ? -85 : 0} seed={3} />
      <Pop a={8.0} b={12.6} x={980} y={190}><WarnIcon /></Pop>
      <Pop a={26.9} b={30.4} x={1700} y={640}><ClockIcon /></Pop>
      <Pop a={30.4} b={32.4} x={730} y={520}><QuestionIcon /></Pop>
      <Pop a={36.6} b={38.7} x={1170} y={480}><ZzzIcon /></Pop>
    </AbsoluteFill>
  );
};
