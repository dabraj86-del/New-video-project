import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {Person} from '../components/Person';
import {Room, WindowFrame, Bed, Blanket} from '../components/Backgrounds';
import {Pop, SunIcon, WarnIcon} from '../components/Icons';
import {ramp, speaking, useGT} from '../timing';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const Scene5: React.FC = () => {
  const t = useGT();
  const ux = interpolate(t, [129.6, 131.6], [-250, 520], cl);
  const walking = t > 129.6 && t < 131.6;
  const uExpr = t >= 149 ? 'shock' : t >= 143.2 ? 'worry' : t >= 134.46 ? 'smile' : 'normal';
  const rLift = (1 - ramp(t, 157.38, 159.6)) * 28;
  const rExpr = t >= 160.3 ? 'creepy' : 'calm';
  const fadeIn = 1 - ramp(t, 127.3, 128.0);
  const hit = t >= 161.92 && t < 162.3 ? 0.35 : 0;
  return (
    <AbsoluteFill>
      <Room mood="day" />
      <WindowFrame x={760} y={130} w={400} h={390} day />
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
        <polygon points="760,520 1160,520 1500,1000 700,1000" fill="#fff3b0" opacity={0.22} />
        <ellipse cx={ux + 110} cy={1006} rx={170} ry={22} fill="#000" opacity={0.45} />
      </svg>
      <Bed x={1000} y={830} w={860} />
      <Person kind="roni" bust x={1380} y={380 + rLift} expr={rExpr} eyesBlack={t >= 160.3} talk={speaking('evil', t) || speaking('roni', t)} floatAmp={3} />
      <Blanket x={1000} y={790} w={860} h={110} color="#2748c9" />
      <Person kind="uncle" x={ux} y={330} walk={walking} expr={uExpr} talk={speaking('uncle', t)} shake={t > 151.5 ? 3 : 0} armR={t >= 143.2 && t < 150 ? -30 : 0} />
      <Pop a={143.3} b={146.0} x={760} y={320}><WarnIcon /></Pop>
      <Pop a={146.0} b={149.06} x={1330} y={260}><SunIcon /></Pop>
      <AbsoluteFill style={{background: '#a00', opacity: hit}} />
      <AbsoluteFill style={{background: '#000', opacity: fadeIn}} />
    </AbsoluteFill>
  );
};
