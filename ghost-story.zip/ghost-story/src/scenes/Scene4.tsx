import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {Person} from '../components/Person';
import {Room} from '../components/Backgrounds';
import {Pop, HeartIcon, WarnIcon} from '../components/Icons';
import {ramp, speaking, useGT} from '../timing';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const Scene4: React.FC = () => {
  const t = useGT();
  const rx = interpolate(t, [103.36, 105.9], [900, 700], cl);
  const walking = t > 103.36 && t < 105.9;
  const gx = interpolate(t, [109.6, 114.4, 119], [1500, 1280, 1100], cl);
  const reach = ramp(t, 109.6, 114.4);
  const len = 150 + 520 * ramp(t, 109.6, 114.4);
  const dark = ramp(t, 124.6, 127.2);
  const rExpr = t >= 105.9 && t < 114.4 ? 'shock' : 'scared';
  const screaming = t >= 114.4 && t < 118.0;
  return (
    <AbsoluteFill>
      <Room mood="dark" />
      <div style={{position: 'absolute', left: 110, top: 280, width: 270, height: 560, background: '#3b2616', border: '8px solid #222'}} />
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
        <ellipse cx={gx - len / 2 + 150} cy={1010} rx={len / 2} ry={26} fill="#000" opacity={0.6} />
        {t >= 107.74 && <ellipse cx={rx} cy={1005} rx={95} ry={20} fill="none" stroke="#fff" strokeWidth={4} strokeDasharray="14 12" opacity={0.6} />}
      </svg>
      <Person kind="ghost" x={gx} y={380} flip expr="creepy" armR={-95 - reach * 20} armL={20} talk={speaking('ghost', t)} floatAmp={10} />
      <Person kind="roni" x={rx} y={300} flip={t < 105.9} walk={walking} expr={rExpr} talk={speaking('roni', t)} shake={screaming ? 4 : 1.5} armL={screaming ? 150 : 0} armR={screaming ? -150 : 0} bag />
      <Pop a={105.9} b={107.7} x={900} y={400}><WarnIcon /></Pop>
      <Pop a={111.0} b={114.4} x={420} y={480}><HeartIcon /></Pop>
      <AbsoluteFill style={{background: '#000', opacity: dark}} />
    </AbsoluteFill>
  );
};
