import {createContext, useContext} from 'react';
import {useCurrentFrame} from 'remotion';

export const FPS = 30;
export const TOTAL_SEC = 220.3; // voice.mp3 = 220.29s
export const END_START = 210.1;

export const f = (s: number) => Math.round(s * FPS);

// ---- Scene-local global-time hook ----
export const SceneCtx = createContext(0);
export const useGT = () => {
  const start = useContext(SceneCtx);
  return useCurrentFrame() / FPS + start;
};
export const ramp = (t: number, a: number, b: number) =>
  Math.min(1, Math.max(0, (t - a) / (b - a)));
export const within = (t: number, a: number, b: number) => t >= a && t <= b;

// ---- Scenes (from SRT) ----
export type SceneInfo = {id: number; start: number; end: number; titleEnd: number; title: string};
export const SCENES: SceneInfo[] = [
  {id: 1, start: 0, end: 39.0, titleEnd: 3.1, title: 'অভিশপ্ত ঘর'},
  {id: 2, start: 39.0, end: 71.0, titleEnd: 42.3, title: 'মধ্যরাতের কান্না'},
  {id: 3, start: 71.0, end: 100.75, titleEnd: 74.18, title: 'ভয়ঙ্কর দৃশ্য'},
  {id: 4, start: 100.75, end: 127.3, titleEnd: 103.36, title: 'নিজের ছায়া'},
  {id: 5, start: 127.3, end: 168.0, titleEnd: 129.6, title: 'পরদিন সকাল'},
  {id: 6, start: 168.0, end: TOTAL_SEC, titleEnd: 171.28, title: 'শেষের আসল ভয়'},
];

// ---- Dialogue callout bubbles ----
export type Who = 'roni' | 'uncle' | 'ghost' | 'evil';
export type Dlg = {a: number; b: number; who: Who; text: string; bx: number; by: number; w: number; tail: number};
export const DLG: Dlg[] = [
  // Scene 1
  {a: 24.44, b: 30.36, who: 'uncle', text: 'বাবা, একটা কথা মনে রাখবে। রাত ১২টার পর ওই শেষ ঘরটার দিকে তাকাবে না।', bx: 1000, by: 370, w: 820, tail: 355},
  {a: 30.36, b: 32.4, who: 'roni', text: 'কেন চাচা?', bx: 260, by: 370, w: 360, tail: 235},
  {a: 33.18, b: 38.54, who: 'uncle', text: 'কারণ ওই ঘরে কেউ থাকে না... অথচ প্রতিরাতে কেউ একজন ঘুমায়।', bx: 1000, by: 370, w: 820, tail: 355},
  // Scene 2
  {a: 51.08, b: 54.6, who: 'ghost', text: 'আমাকে বের করো... দয়া করে আমাকে বের করো...', bx: 1050, by: 330, w: 700, tail: 475},
  {a: 62.58, b: 64.9, who: 'ghost', text: 'রনি... তুমি এসেছ?', bx: 1150, by: 330, w: 560, tail: 375},
  // Scene 3
  {a: 83.3, b: 85.3, who: 'ghost', text: 'তুমি কি আমাকে দেখতে পাচ্ছ?', bx: 900, by: 230, w: 760, tail: 205},
  {a: 85.84, b: 87.9, who: 'roni', text: 'হ্যাঁ... তুমি কে?', bx: 120, by: 330, w: 520, tail: 305},
  {a: 94.66, b: 97.0, who: 'ghost', text: 'তাহলে তুমি এখনো বেঁচে আছ...', bx: 900, by: 230, w: 760, tail: 205},
  // Scene 4
  {a: 115.98, b: 118.0, who: 'roni', text: 'আমাকে ছেড়ে দাও!', bx: 400, by: 340, w: 520, tail: 275},
  {a: 119.26, b: 124.6, who: 'ghost', text: 'তোমার ছায়াটা আমার খুব পছন্দ হয়েছে। আজ থেকে এটা আমার...', bx: 980, by: 420, w: 800, tail: 495},
  // Scene 5
  {a: 137.36, b: 140.2, who: 'uncle', text: 'বাবা, কাল রাতে কিছু শুনেছিলে?', bx: 160, by: 370, w: 700, tail: 335},
  {a: 140.58, b: 143.3, who: 'roni', text: 'না চাচা, কিছুই না।', bx: 1050, by: 430, w: 520, tail: 305},
  {a: 155.0, b: 157.0, who: 'uncle', text: 'তুমি... তুমি কে?', bx: 160, by: 370, w: 520, tail: 335},
  {a: 161.92, b: 168.0, who: 'evil', text: 'আমি রনি নই চাচা... আমি সেই মেয়ে, যে এতদিন ওই ঘরে বন্দি ছিলাম।', bx: 1000, by: 430, w: 800, tail: 355},
  // Scene 6
  {a: 178.0, b: 182.0, who: 'roni', text: 'চাচা! দরজা খুলুন! আমাকে বাঁচান!', bx: 520, by: 290, w: 800, tail: 380},
  {a: 191.74, b: 195.5, who: 'ghost', text: 'একজনকে তো পেয়েছি... এবার আপনাকে চাই!', bx: 1000, by: 330, w: 800, tail: 475},
];
export const speaking = (who: Who, t: number) => DLG.some((d) => d.who === who && within(t, d.a, d.b));

// ---- Keyword stamps ----
export type StampInfo = {a: number; b: number; text: string; color: string; x: number; y: number; rot: number};
export const STAMPS: StampInfo[] = [
  {a: 42.34, b: 44.0, text: 'রাত ১২:৩০', color: '#ffd34d', x: 960, y: 300, rot: -4},
  {a: 107.74, b: 111.0, text: 'ছায়া নেই!', color: '#ff4d4d', x: 1000, y: 250, rot: -5},
  {a: 149.06, b: 151.5, text: 'রনির ছায়া নেই!', color: '#ff4d4d', x: 960, y: 250, rot: 3},
];

// ---- Selective bottom captions (only when no bubble/stamp/title/end card) ----
export type Cap = {a: number; b: number; text: string};
export const CAPS: Cap[] = [
  // S1
  {a: 3.1, b: 6.0, text: 'একটি ছোট গ্রামে [[পুরোনো বাড়ি]]'},
  {a: 6.08, b: 8.84, text: '[[একটি ঘর]] কখনো কেউ খুলত না'},
  {a: 8.84, b: 12.58, text: 'বৃদ্ধরা বলত, ঘরে [[একবার ঢুকলে]]'},
  {a: 12.58, b: 14.96, text: 'আর আগের [[মানুষ]] ফেরে না'},
  {a: 14.96, b: 19.36, text: 'রনি এল [[কাজের সন্ধানে]]'},
  {a: 19.36, b: 21.84, text: 'মালিক দিলেন [[থাকার ঘর]]'},
  {a: 21.84, b: 23.6, text: 'কিন্তু একটা [[শর্ত]] ছিল—'},
  // S2
  {a: 44.0, b: 45.84, text: 'রনি [[বিছানায় শুয়ে]] ছিল'},
  {a: 45.84, b: 48.72, text: 'পাশের ঘর থেকে [[কান্নার শব্দ]]'},
  {a: 48.72, b: 50.9, text: 'একটি মেয়ে [[কাঁদছে]]'},
  {a: 54.6, b: 57.0, text: 'রনি [[সাহস করে]] দরজার কাছে'},
  {a: 57.0, b: 60.3, text: 'শেষ ঘরের দরজা [[একটু খোলা]]'},
  {a: 60.38, b: 62.4, text: 'ভেতর থেকে [[আবার শব্দ]]'},
  {a: 65.52, b: 67.32, text: 'রনি [[অবাক]] হয়ে গেল'},
  {a: 67.32, b: 70.7, text: 'এ বাড়িতে কেউ তার [[নাম জানত না]]'},
  // S3
  {a: 74.18, b: 76.34, text: 'রনি দরজা ঠেলে [[ঢুকল]]'},
  {a: 76.34, b: 78.74, text: 'ঘরে একটি [[পুরোনো আয়না]]'},
  {a: 78.74, b: 82.38, text: 'আয়নার সামনে [[সাদা শাড়ি]] পরা মেয়ে'},
  {a: 88.46, b: 90.82, text: 'মেয়েটি [[ঘুরে দাঁড়াল]]'},
  {a: 90.82, b: 94.6, text: 'চোখ দুটো [[কালো]], মুখে [[হাসি নেই]]'},
  {a: 97.54, b: 100.7, text: 'দরজা [[নিজে থেকেই বন্ধ]] হয়ে গেল'},
  // S4
  {a: 103.4, b: 105.9, text: 'রনি [[দৌড়ে]] বের হতে গেল'},
  {a: 105.9, b: 107.7, text: 'চোখ পড়ল [[মেঝেতে]]'},
  {a: 111.0, b: 114.4, text: 'মেয়েটির ছায়া [[এগিয়ে আসছে]]'},
  {a: 114.4, b: 115.98, text: 'রনি [[চিৎকার]] করল'},
  {a: 118.0, b: 119.2, text: 'মেয়েটি [[হেসে]] বলল'},
  {a: 125.0, b: 127.3, text: 'সব [[অন্ধকার]] হয়ে গেল'},
  // S5
  {a: 129.6, b: 134.46, text: 'সকালে রনি [[বিছানায় বসে]] আছে'},
  {a: 134.46, b: 136.7, text: 'মালিক [[স্বস্তির]] নিঃশ্বাস ফেললেন'},
  {a: 143.3, b: 146.0, text: 'মালিক হঠাৎ [[থমকে]] গেলেন'},
  {a: 146.0, b: 149.06, text: 'জানালা দিয়ে [[সূর্যের আলো]] পড়েছে'},
  {a: 151.5, b: 154.8, text: 'মালিক [[কাঁপা গলায়]] বললেন'},
  {a: 157.38, b: 160.5, text: 'রনি ধীরে ধীরে [[মাথা তুলল]]'},
  // S6
  {a: 171.28, b: 174.0, text: 'মালিক ভয়ে [[পেছনে সরে]] গেলেন'},
  {a: 174.0, b: 177.9, text: 'বাইরে থেকে রনির [[আসল কণ্ঠ]]'},
  {a: 182.0, b: 184.7, text: 'বাইরে [[রনি]] দাঁড়িয়ে আছে'},
  {a: 184.7, b: 187.7, text: 'ঘরের ভেতরে যে [[বসে আছে]]'},
  {a: 187.7, b: 189.8, text: 'সে ধীরে ধীরে [[হাসছে]]'},
  {a: 189.8, b: 191.7, text: 'ফিসফিস করে [[বলল]]'},
  {a: 195.5, b: 197.8, text: 'হঠাৎ [[দরজা বন্ধ]] হয়ে গেল'},
  {a: 197.8, b: 201.4, text: 'ওই বাড়িতে [[কাউকে]] দেখা যায়নি'},
  {a: 201.4, b: 206.98, text: 'জানালায় দুটো [[ছায়া]] দেখা যায়'},
  {a: 206.98, b: 209.9, text: 'অথচ ভেতরে [[কোনো মানুষ নেই]]!'},
];

export const captionBusy = (t: number) =>
  DLG.some((d) => within(t, d.a, d.b + 0.3)) ||
  STAMPS.some((s) => within(t, s.a, s.b)) ||
  SCENES.some((s) => t >= s.start && t < s.titleEnd) ||
  t >= END_START - 0.1;

// ---- Screen shake windows ----
export const SHAKES: {a: number; b: number; amp: number}[] = [
  {a: 97.4, b: 99.2, amp: 10},
  {a: 114.4, b: 118.0, amp: 6},
  {a: 124.4, b: 125.6, amp: 12},
  {a: 151.5, b: 153.0, amp: 5},
  {a: 161.92, b: 163.2, amp: 10},
  {a: 195.4, b: 196.6, amp: 12},
];

// ---- Sound effects (volume always below the voice-over) ----
export type Sfx = {t: number; file: string; dur: number; vol: number};
export const SFX: Sfx[] = [
  {t: 15.0, file: 'steps', dur: 3.2, vol: 0.28},
  {t: 26.0, file: 'knock', dur: 2.8, vol: 0.4},
  {t: 48.8, file: 'cry', dur: 5.6, vol: 0.32},
  {t: 54.6, file: 'heartbeat', dur: 3.6, vol: 0.45},
  {t: 78.6, file: 'heartbeat', dur: 4.2, vol: 0.45},
  {t: 97.4, file: 'hit', dur: 2.6, vol: 0.45},
  {t: 107.7, file: 'hit', dur: 2.6, vol: 0.45},
  {t: 110.6, file: 'steps', dur: 4.0, vol: 0.3},
  {t: 124.4, file: 'scream', dur: 3.2, vol: 0.4},
  {t: 161.9, file: 'hit', dur: 2.6, vol: 0.45},
  {t: 178.4, file: 'knock', dur: 2.8, vol: 0.4},
  {t: 195.2, file: 'scream', dur: 3.4, vol: 0.4},
];
