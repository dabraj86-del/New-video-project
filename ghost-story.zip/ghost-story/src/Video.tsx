import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {FPS, SCENES, SFX, SHAKES, SceneCtx, f} from './timing';
import {Overlay} from './components/Overlay';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Scene5} from './scenes/Scene5';
import {Scene6} from './scenes/Scene6';

const COMPS = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6];

const Fade: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const fr = useCurrentFrame();
  const o = Math.max(interpolate(fr, [0, 10], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}), interpolate(fr, [dur - 6, dur], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
  return (
    <AbsoluteFill>
      {children}
      <AbsoluteFill style={{background: '#000', opacity: o}} />
    </AbsoluteFill>
  );
};

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const sh = SHAKES.find((s) => t >= s.a && t <= s.b);
  const dx = sh ? Math.sin(frame * 3.1) * sh.amp : 0;
  const dy = sh ? Math.cos(frame * 4.3) * sh.amp * 0.7 : 0;
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Audio src={staticFile('voice.mp3')} volume={1} />
      {SFX.map((s, i) => {
        const d = f(s.dur);
        return (
          <Sequence key={i} from={f(s.t)} durationInFrames={d}>
            <Audio
              src={staticFile(`sfx/${s.file}.mp3`)}
              volume={(fr) => interpolate(fr, [0, 5, d - 12, d], [0, s.vol, s.vol, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}
            />
          </Sequence>
        );
      })}
      <AbsoluteFill style={{transform: `translate(${dx}px, ${dy}px) scale(${sh ? 1.03 : 1})`}}>
        {SCENES.map((s, i) => {
          const C = COMPS[i];
          const dur = f(s.end) - f(s.start);
          return (
            <Sequence key={s.id} from={f(s.start)} durationInFrames={dur}>
              <SceneCtx.Provider value={s.start}>
                <Fade dur={dur}>
                  <C />
                </Fade>
              </SceneCtx.Provider>
            </Sequence>
          );
        })}
      </AbsoluteFill>
      <AbsoluteFill style={{pointerEvents: 'none', background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%)'}} />
      <Overlay />
    </AbsoluteFill>
  );
};
